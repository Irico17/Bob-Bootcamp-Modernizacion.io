# Lab: Sistema de Gestión de Empleados

# Alcance del Hands-On

Este lab se centra en el uso de **Bob** para acelerar la comprensión, documentación y modernización de una aplicación Java existente.

## Documentación Automatizada 📚

Uso de agentes para analizar el proyecto existente y generar documentación técnica.

Beneficios clave:

- Comprensión rápida de proyectos existentes
- Generación consistente de documentación
- Reducción del esfuerzo manual de documentación

## Modernización Java ☕

Uso del paquete de modernización Java de Bob para actualizar la versión del lenguaje y migrar dependencias obsoletas.

Beneficios clave:

- Detección automática de versiones desactualizadas
- Aplicación de recetas de migración probadas
- Reducción del riesgo de regresiones

# Flujo del Laboratorio

Durante este laboratorio se realizarán las siguientes actividades:

## 1. Analizar la solución existente y generar documentación técnica

El participante abrirá el proyecto en Bob y le solicitará una explicación inicial de la arquitectura y los componentes disponibles, seguida de la generación de documentación técnica formal.

**Objetivo:** comprender qué componentes existen y producir documentación clara antes de modernizar el código.

**Prompt ejemplo:**

```
Analiza este proyecto Java y genera documentación técnica completa en español.

La documentación debe incluir:
- descripción general de la solución y su propósito
- stack tecnológico utilizado (versiones exactas del pom.xml)
- estructura del repositorio y responsabilidad de cada capa
- modelos de datos (entidades JPA y sus relaciones)
- endpoints REST disponibles con métodos, URLs y descripción
- configuración requerida en application.properties
- supuestos y restricciones de la aplicación
- pasos para ejecutar la solución localmente
- posibles mejoras o extensiones del sistema
```

## 2. Modernizar la aplicación usando el paquete Java de Bob

Una vez comprendida y documentada la solución, el participante le pedirá a Bob que aplique las recetas de modernización Java disponibles para actualizar la versión del lenguaje y las dependencias obsoletas.

**Objetivo:** llevar la aplicación a una versión moderna de Java y Spring Boot, eliminando dependencias desactualizadas y aplicando las mejores prácticas actuales.

**Prompt ejemplo:**

```
Moderniza esta aplicación Java usando el paquete de modernización de Java de Bob.

Por favor:
- detecta la versión actual de Java y Spring Boot en uso
- identifica dependencias desactualizadas o con vulnerabilidades conocidas
- aplica las recetas de migración disponibles para actualizar a una versión moderna de Java
- actualiza Spring Boot a la versión estable más reciente compatible
- reporta los cambios aplicados y cualquier ajuste manual necesario
- verifica que el proyecto compile y los tests pasen tras la modernización
```

## 3. Ejecutar y validar la aplicación modernizada
Después de completar la modernización, el participante ejecutará la aplicación desde la carpeta raíz del proyecto para verificar que inicia correctamente y que no existen errores de compilación o configuración.
Objetivo: comprobar de forma práctica que la aplicación modernizada puede ejecutarse correctamente en un entorno local.
En macOS o Linux:
```
./mvnw spring-boot:run
```
En Windows:
```
mvnw.cmd spring-boot:run
```
Una vez iniciada la aplicación, el participante podrá revisar la consola para confirmar que Spring Boot se levantó correctamente y acceder a los endpoints disponibles para validar su funcionamiento.

---

# Resultado Esperado

Al finalizar el laboratorio, los participantes contarán con:

- Documentación técnica completa generada automáticamente por Bob
- La aplicación migrada a una versión moderna de Java y SpringBoot con dependencias actualizadas
- Una comprensión práctica del flujo de análisis, documentación y modernización asistido por agentes
