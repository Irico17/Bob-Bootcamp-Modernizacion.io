package com.claro.lab.pricing;

import com.claro.lab.pricing.FareCalculator.PlanType;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.ValueSource;

import java.math.BigDecimal;

import static com.claro.lab.pricing.FareCalculator.PlanType.*;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.junit.jupiter.api.Assertions.assertThrows;

@DisplayName("FareCalculator")
class FareCalculatorTest {

    private final FareCalculator calculator = new FareCalculator();

    // ─────────────────────────────────────────────────────────────────────────
    // Validaciones de entrada
    // ─────────────────────────────────────────────────────────────────────────

    @Nested
    @DisplayName("Validaciones de parámetros de entrada")
    class InputValidation {

        @Test
        @DisplayName("planType nulo lanza NullPointerException")
        void nullPlanType_throwsNullPointerException() {
            assertThrows(NullPointerException.class,
                    () -> calculator.calculate(null, 0, 0, false));
        }

        @ParameterizedTest
        @ValueSource(ints = {-1, -100})
        @DisplayName("minutesUsed negativo lanza IllegalArgumentException")
        void negativeMinutes_throwsIllegalArgumentException(int minutes) {
            assertThrows(IllegalArgumentException.class,
                    () -> calculator.calculate(PREPAID, minutes, 0, false));
        }

        @ParameterizedTest
        @ValueSource(ints = {-1, -500})
        @DisplayName("dataMbUsed negativo lanza IllegalArgumentException")
        void negativeData_throwsIllegalArgumentException(int dataMb) {
            assertThrows(IllegalArgumentException.class,
                    () -> calculator.calculate(PREPAID, 0, dataMb, false));
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Plan PREPAID
    // ─────────────────────────────────────────────────────────────────────────

    @Nested
    @DisplayName("Plan PREPAID")
    class PrepaidPlan {

        @Test
        @DisplayName("Solo voz sin horario pico cobra minutos × 0.45")
        void prepaid_offPeak_voiceOnly_chargesCorrectly() {
            BigDecimal result = calculator.calculate(PREPAID, 10, 0, false);
            assertThat(result).isEqualByComparingTo("4.50");
        }

        @Test
        @DisplayName("Solo datos sin horario pico cobra MB × 0.08")
        void prepaid_offPeak_dataOnly_chargesCorrectly() {
            BigDecimal result = calculator.calculate(PREPAID, 0, 100, false);
            assertThat(result).isEqualByComparingTo("8.00");
        }

        @Test
        @DisplayName("Horario pico aplica multiplicador 1.25 sobre subtotal positivo")
        void prepaid_peak_appliesMultiplier() {
            BigDecimal result = calculator.calculate(PREPAID, 10, 0, true);
            // 10 × 0.45 = 4.50 × 1.25 = 5.625 → redondea a 5.63
            assertThat(result).isEqualByComparingTo("5.63");
        }

        @Test
        @DisplayName("Horario pico con subtotal 0 no aplica multiplicador")
        void prepaid_peak_zeroSubtotal_noMultiplier() {
            BigDecimal result = calculator.calculate(PREPAID, 0, 0, true);
            assertThat(result).isEqualByComparingTo("0.00");
        }

        @Test
        @DisplayName("Voz + datos sin pico suma ambos cargos")
        void prepaid_offPeak_voiceAndData_sumsBoth() {
            // 5 × 0.45 = 2.25  +  50 × 0.08 = 4.00  → 6.25
            BigDecimal result = calculator.calculate(PREPAID, 5, 50, false);
            assertThat(result).isEqualByComparingTo("6.25");
        }

        @ParameterizedTest(name = "{0} min → {1}")
        @CsvSource({
            "1,  0.45",
            "20, 9.00",
            "100, 45.00"
        })
        @DisplayName("Tabla de tarifas PREPAID sin pico para varios minutos")
        void prepaid_offPeak_multipleMinutes(int minutes, String expected) {
            BigDecimal result = calculator.calculate(PREPAID, minutes, 0, false);
            assertThat(result).isEqualByComparingTo(expected);
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Plan POSTPAID
    // ─────────────────────────────────────────────────────────────────────────

    @Nested
    @DisplayName("Plan POSTPAID")
    class PostpaidPlan {

        @Test
        @DisplayName("Datos dentro de la franquicia (≤ 500 MB) no generan cargo de datos")
        void postpaid_dataWithinFranchise_zeroDataCharge() {
            BigDecimal result = calculator.calculate(POSTPAID, 0, 500, false);
            assertThat(result).isEqualByComparingTo("0.00");
        }

        @Test
        @DisplayName("Datos sobre la franquicia cobra solo el excedente")
        void postpaid_dataOverFranchise_chargesExcessOnly() {
            // 600 MB - 500 MB = 100 excedente × 0.08 = 8.00
            BigDecimal result = calculator.calculate(POSTPAID, 0, 600, false);
            assertThat(result).isEqualByComparingTo("8.00");
        }

        @Test
        @DisplayName("Voz POSTPAID cobra minutos × 0.30")
        void postpaid_voiceOnly_chargesCorrectly() {
            BigDecimal result = calculator.calculate(POSTPAID, 10, 0, false);
            assertThat(result).isEqualByComparingTo("3.00");
        }

        @Test
        @DisplayName("Datos exactamente iguales a la franquicia no generan cargo")
        void postpaid_dataExactlyAtFranchise_zeroDataCharge() {
            BigDecimal result = calculator.calculate(POSTPAID, 0, 500, false);
            assertThat(result).isEqualByComparingTo("0.00");
        }

        @Test
        @DisplayName("Pico aplica multiplicador sobre voz + excedente de datos")
        void postpaid_peak_appliesMultiplierOnExcess() {
            // 10 min × 0.30 = 3.00  +  100 MB exceso × 0.08 = 8.00 → subtotal 11.00 × 1.25 = 13.75
            BigDecimal result = calculator.calculate(POSTPAID, 10, 600, true);
            assertThat(result).isEqualByComparingTo("13.75");
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Plan CORPORATE
    // ─────────────────────────────────────────────────────────────────────────

    @Nested
    @DisplayName("Plan CORPORATE")
    class CorporatePlan {

        @Test
        @DisplayName("Minutos dentro de los 100 gratuitos no generan cargo de voz")
        void corporate_minutesWithinFree_zeroVoiceCharge() {
            BigDecimal result = calculator.calculate(CORPORATE, 100, 0, false);
            assertThat(result).isEqualByComparingTo("0.00");
        }

        @Test
        @DisplayName("Minutos sobre la franquicia cobra solo el excedente × 0.18")
        void corporate_minutesOverFree_chargesExcessOnly() {
            // 120 - 100 = 20 excedente × 0.18 = 3.60
            BigDecimal result = calculator.calculate(CORPORATE, 120, 0, false);
            assertThat(result).isEqualByComparingTo("3.60");
        }

        @Test
        @DisplayName("Datos cobran con descuento del 15% (coeficiente 0.85)")
        void corporate_data_applies15PercentDiscount() {
            // 100 MB × 0.08 × 0.85 = 6.80
            BigDecimal result = calculator.calculate(CORPORATE, 0, 100, false);
            assertThat(result).isEqualByComparingTo("6.80");
        }

        @Test
        @DisplayName("Datos = 0 no genera cargo aunque hay descuento corporativo")
        void corporate_zeroData_zeroDataCharge() {
            BigDecimal result = calculator.calculate(CORPORATE, 0, 0, false);
            assertThat(result).isEqualByComparingTo("0.00");
        }

        @Test
        @DisplayName("Voz + datos con descuento corporativo suma ambos cargos correctamente")
        void corporate_voiceAndData_combinesCharges() {
            // 50 min (dentro franquicia) → voz = 0
            // 200 MB × 0.08 × 0.85 = 13.60
            BigDecimal result = calculator.calculate(CORPORATE, 50, 200, false);
            assertThat(result).isEqualByComparingTo("13.60");
        }

        @Test
        @DisplayName("Pico aplica multiplicador sobre subtotal de voz + datos corporativos")
        void corporate_peak_appliesMultiplierOnSubtotal() {
            // 110 min → 10 exceso × 0.18 = 1.80
            // 100 MB × 0.08 × 0.85 = 6.80 → subtotal 8.60 × 1.25 = 10.75
            BigDecimal result = calculator.calculate(CORPORATE, 110, 100, true);
            assertThat(result).isEqualByComparingTo("10.75");
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Caso borde: todo en cero
    // ─────────────────────────────────────────────────────────────────────────

    @Test
    @DisplayName("Todo en cero (minutos=0, datos=0) devuelve 0.00 en cualquier plan")
    void allZero_returnsZero() {
        for (PlanType plan : PlanType.values()) {
            assertThat(calculator.calculate(plan, 0, 0, false))
                    .as("Plan %s con cero consumo", plan)
                    .isEqualByComparingTo("0.00");
        }
    }

    @Test
    @DisplayName("Resultado siempre se escala a 2 decimales")
    void result_alwaysScaledToTwoDecimals() {
        BigDecimal result = calculator.calculate(PREPAID, 1, 0, false);
        assertThat(result.scale()).isEqualTo(2);
    }

    @Test
    @DisplayName("Mensaje de IllegalArgumentException menciona el valor inválido para minutesUsed")
    void negativeMinutes_exceptionMessageContainsValue() {
        assertThatThrownBy(() -> calculator.calculate(PREPAID, -5, 0, false))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessageContaining("-5");
    }

    @Test
    @DisplayName("Mensaje de IllegalArgumentException menciona el valor inválido para dataMbUsed")
    void negativeData_exceptionMessageContainsValue() {
        assertThatThrownBy(() -> calculator.calculate(PREPAID, 0, -3, false))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessageContaining("-3");
    }
}
