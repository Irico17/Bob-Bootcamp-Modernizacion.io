package com.claro.lab.reservation;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;

import java.time.LocalDateTime;

import static org.junit.jupiter.api.Assertions.*;

@DisplayName("Reservation")
class ReservationTest {

    private static final LocalDateTime BASE = LocalDateTime.of(2024, 6, 10, 10, 0);

    // -------------------------------------------------------------------------
    // Constructor y getters
    // -------------------------------------------------------------------------

    @Nested
    @DisplayName("Constructor")
    class Constructor {

        @Test
        @DisplayName("Constructor válido: objeto se crea sin excepciones")
        void validArgs_createsObject() {
            Reservation r = new Reservation("R1", "STORE-1", BASE, 30);

            assertEquals("R1", r.getReservationId());
            assertEquals("STORE-1", r.getStoreId());
            assertEquals(BASE, r.getSlotStart());
            assertEquals(30, r.getDurationMinutes());
        }

        @Test
        @DisplayName("durationMinutes = 0 lanza IllegalArgumentException")
        void zeroDuration_throwsIllegalArgumentException() {
            assertThrows(IllegalArgumentException.class,
                    () -> new Reservation("R1", "STORE-1", BASE, 0));
        }

        @Test
        @DisplayName("durationMinutes negativo lanza IllegalArgumentException")
        void negativeDuration_throwsIllegalArgumentException() {
            assertThrows(IllegalArgumentException.class,
                    () -> new Reservation("R1", "STORE-1", BASE, -10));
        }

        @Test
        @DisplayName("reservationId nulo lanza NullPointerException")
        void nullReservationId_throwsNullPointerException() {
            assertThrows(NullPointerException.class,
                    () -> new Reservation(null, "STORE-1", BASE, 30));
        }

        @Test
        @DisplayName("storeId nulo lanza NullPointerException")
        void nullStoreId_throwsNullPointerException() {
            assertThrows(NullPointerException.class,
                    () -> new Reservation("R1", null, BASE, 30));
        }

        @Test
        @DisplayName("slotStart nulo lanza NullPointerException")
        void nullSlotStart_throwsNullPointerException() {
            assertThrows(NullPointerException.class,
                    () -> new Reservation("R1", "STORE-1", null, 30));
        }
    }

    // -------------------------------------------------------------------------
    // getSlotEnd
    // -------------------------------------------------------------------------

    @Nested
    @DisplayName("getSlotEnd")
    class GetSlotEnd {

        @Test
        @DisplayName("getSlotEnd = slotStart + durationMinutes")
        void slotEnd_equalsStartPlusDuration() {
            Reservation r = new Reservation("R1", "STORE-1", BASE, 45);
            assertEquals(BASE.plusMinutes(45), r.getSlotEnd());
        }
    }

    // -------------------------------------------------------------------------
    // overlaps
    // -------------------------------------------------------------------------

    @Nested
    @DisplayName("overlaps")
    class Overlaps {

        @Test
        @DisplayName("Solapamiento completo: other totalmente dentro → true")
        void completeOverlap_returnsTrue() {
            Reservation a = new Reservation("A", "S1", BASE, 60);            // 10:00–11:00
            Reservation b = new Reservation("B", "S1", BASE.plusMinutes(10), 20); // 10:10–10:30
            assertTrue(a.overlaps(b));
        }

        @Test
        @DisplayName("Solapamiento parcial al inicio → true")
        void partialOverlapAtStart_returnsTrue() {
            Reservation a = new Reservation("A", "S1", BASE, 60);                 // 10:00–11:00
            Reservation b = new Reservation("B", "S1", BASE.minusMinutes(30), 60); // 09:30–10:30
            assertTrue(a.overlaps(b));
        }

        @Test
        @DisplayName("Solapamiento parcial al final → true")
        void partialOverlapAtEnd_returnsTrue() {
            Reservation a = new Reservation("A", "S1", BASE, 60);                  // 10:00–11:00
            Reservation b = new Reservation("B", "S1", BASE.plusMinutes(30), 60);  // 10:30–11:30
            assertTrue(a.overlaps(b));
        }

        @Test
        @DisplayName("Sin solapamiento: b empieza cuando a termina (adyacentes) → false")
        void adjacentSlots_noOverlap_returnsFalse() {
            Reservation a = new Reservation("A", "S1", BASE, 60);                  // 10:00–11:00
            Reservation b = new Reservation("B", "S1", BASE.plusMinutes(60), 30);  // 11:00–11:30
            assertFalse(a.overlaps(b));
        }

        @Test
        @DisplayName("Sin solapamiento: b termina antes de que a empiece → false")
        void noOverlap_beforeStart_returnsFalse() {
            Reservation a = new Reservation("A", "S1", BASE, 30);                     // 10:00–10:30
            Reservation b = new Reservation("B", "S1", BASE.minusMinutes(60), 30);    // 09:00–09:30
            assertFalse(a.overlaps(b));
        }

        @Test
        @DisplayName("other nulo lanza NullPointerException")
        void nullOther_throwsNullPointerException() {
            Reservation a = new Reservation("A", "S1", BASE, 30);
            assertThrows(NullPointerException.class, () -> a.overlaps(null));
        }
    }
}
