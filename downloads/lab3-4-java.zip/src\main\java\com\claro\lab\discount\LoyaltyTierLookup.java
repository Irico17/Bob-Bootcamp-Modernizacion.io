package com.claro.lab.discount;

/**
 * Colaborador inyectable: obtiene el nivel de lealtad de un cliente.
 * En tests se mockea con Mockito.
 */
public interface LoyaltyTierLookup {

    /**
     * @param customerId identificador del cliente
     * @return nivel de lealtad; nunca null
     * @throws IllegalArgumentException si customerId es inválido
     */
    LoyaltyTier findTier(String customerId);
}
