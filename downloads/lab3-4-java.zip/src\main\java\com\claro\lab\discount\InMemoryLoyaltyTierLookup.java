package com.claro.lab.discount;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Implementación en memoria de {@link LoyaltyTierLookup} para poder ejecutar
 * la aplicación de forma autónoma (sin BD ni API externa) en el Lab 4.
 *
 * <p>En un sistema real, esta clase consultaría una base de datos o un
 * microservicio; aquí devuelve niveles precargados para clientes de ejemplo.
 */
public class InMemoryLoyaltyTierLookup implements LoyaltyTierLookup {

    private final Map<String, LoyaltyTier> tiers = new ConcurrentHashMap<>();

    public InMemoryLoyaltyTierLookup() {
        tiers.put("C1", LoyaltyTier.SILVER);
        tiers.put("C2", LoyaltyTier.GOLD);
        tiers.put("C3", LoyaltyTier.PLATINUM);
    }

    @Override
    public LoyaltyTier findTier(String customerId) {
        if (customerId == null || customerId.isBlank()) {
            throw new IllegalArgumentException("customerId es obligatorio");
        }
        return tiers.getOrDefault(customerId.trim(), LoyaltyTier.NONE);
    }
}
