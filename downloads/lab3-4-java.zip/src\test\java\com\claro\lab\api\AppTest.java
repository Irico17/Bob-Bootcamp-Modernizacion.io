package com.claro.lab.api;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;

import java.io.IOException;
import java.lang.reflect.Method;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.URL;
import java.nio.charset.StandardCharsets;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Pruebas de integración ligera para {@link App}.
 *
 * <p>Estrategia: se obtienen los handlers privados de {@code App} vía reflexión
 * y se registran en un {@link HttpServer} del JDK arrancado en un puerto libre.
 * Así se prueba el comportamiento real de cada handler sin depender del método
 * {@code main} ni de variables de entorno.
 *
 * <p>Prioridad: 🔵 Baja (infraestructura). Umbral JaCoCo: ≥ 50% instrucciones.
 */
@DisplayName("App — servidor HTTP embebido")
class AppTest {

    private int port;
    private HttpServer server;

    // -------------------------------------------------------------------------
    // Infraestructura de arranque / parada del servidor
    // -------------------------------------------------------------------------

    @BeforeEach
    void iniciarServidor() throws Exception {
        port = puertoLibre();
        server = HttpServer.create(new InetSocketAddress("127.0.0.1", port), 0);

        server.createContext("/health",   exchange -> invocarHandler("handleHealth",   exchange));
        server.createContext("/fare",     exchange -> invocarHandler("handleFare",     exchange));
        server.createContext("/discount", exchange -> invocarHandler("handleDiscount", exchange));
        server.createContext("/",         exchange -> invocarHandler("handleRoot",     exchange));

        server.setExecutor(null);
        server.start();
    }

    @AfterEach
    void detenerServidor() {
        if (server != null) {
            server.stop(0);
        }
    }

    /**
     * Invoca un método privado estático de {@link App} por reflexión.
     * Necesario porque los handlers son {@code private static}.
     */
    private static void invocarHandler(String nombreMetodo, HttpExchange exchange) throws IOException {
        try {
            Method m = App.class.getDeclaredMethod(nombreMetodo, HttpExchange.class);
            m.setAccessible(true);
            m.invoke(null, exchange);
        } catch (java.lang.reflect.InvocationTargetException e) {
            Throwable cause = e.getCause();
            if (cause instanceof IOException) {
                throw (IOException) cause;
            }
            throw new IOException("Error invocando " + nombreMetodo, cause);
        } catch (ReflectiveOperationException e) {
            throw new IOException("Reflexión fallida para " + nombreMetodo, e);
        }
    }

    private int puertoLibre() throws IOException {
        try (ServerSocket s = new ServerSocket(0)) {
            return s.getLocalPort();
        }
    }

    private HttpURLConnection get(String path) throws IOException {
        URL url = new URL("http://127.0.0.1:" + port + path);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("GET");
        return conn;
    }

    /** Lee el cuerpo de la respuesta sin importar si es éxito o error HTTP. */
    private String leerCuerpo(HttpURLConnection conn) throws IOException {
        int code = conn.getResponseCode();
        try (var is = code < 400 ? conn.getInputStream() : conn.getErrorStream()) {
            return new String(is.readAllBytes(), StandardCharsets.UTF_8);
        }
    }

    // =========================================================================
    // /health
    // =========================================================================

    @Nested
    @DisplayName("/health")
    class Health {

        @Test
        @DisplayName("GET retorna 200 y body con status UP")
        void get_retorna200_statusUp() throws IOException {
            HttpURLConnection conn = get("/health");
            assertEquals(200, conn.getResponseCode());
            assertTrue(leerCuerpo(conn).contains("\"status\":\"UP\""));
        }

        @Test
        @DisplayName("POST retorna 405 method not allowed")
        void post_retorna405_methodNotAllowed() throws IOException {
            URL url = new URL("http://127.0.0.1:" + port + "/health");
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setDoOutput(true);
            conn.getOutputStream().write(new byte[0]);

            assertEquals(405, conn.getResponseCode());
            assertTrue(leerCuerpo(conn).contains("method not allowed"));
        }
    }

    // =========================================================================
    // /fare
    // =========================================================================

    @Nested
    @DisplayName("/fare")
    class Fare {

        @Test
        @DisplayName("GET sin parámetros usa valores por defecto — cargo 0.00")
        void sinParametros_usaDefectos_retornaCero() throws IOException {
            HttpURLConnection conn = get("/fare");
            assertEquals(200, conn.getResponseCode());
            // charge es un número JSON (sin comillas): "charge":0.00
            assertTrue(leerCuerpo(conn).contains("\"charge\":0.00"));
        }

        @Test
        @DisplayName("GET PREPAID 10 min sin pico — 10 × 0.45 = 4.50")
        void prepaid_sinPico_retornaCargoEsperado() throws IOException {
            HttpURLConnection conn = get("/fare?plan=PREPAID&minutes=10&data=0&peak=false");
            assertEquals(200, conn.getResponseCode());
            String body = leerCuerpo(conn);
            // charge es un número JSON (sin comillas): "charge":4.50
            assertTrue(body.contains("\"charge\":4.50"), "body: " + body);
        }

        @Test
        @DisplayName("GET PREPAID 10 min con pico — 4.50 × 1.25 = 5.63")
        void prepaid_conPico_aplicaMultiplicador() throws IOException {
            HttpURLConnection conn = get("/fare?plan=PREPAID&minutes=10&data=0&peak=true");
            assertEquals(200, conn.getResponseCode());
            String body = leerCuerpo(conn);
            // charge es un número JSON (sin comillas): "charge":5.63
            assertTrue(body.contains("\"charge\":5.63"), "body: " + body);
        }

        @Test
        @DisplayName("GET POSTPAID datos ≤ 500 MB — datos gratis, cargo 0.00")
        void postpaid_datosDentroFranquicia_datosGratis() throws IOException {
            HttpURLConnection conn = get("/fare?plan=POSTPAID&minutes=0&data=500&peak=false");
            assertEquals(200, conn.getResponseCode());
            String body = leerCuerpo(conn);
            // charge es un número JSON (sin comillas): "charge":0.00
            assertTrue(body.contains("\"charge\":0.00"), "body: " + body);
        }

        @Test
        @DisplayName("GET CORPORATE minutos ≤ 100 gratis — cargo de voz 0.00")
        void corporate_minutosDentroFranquicia_vocesGratis() throws IOException {
            HttpURLConnection conn = get("/fare?plan=CORPORATE&minutes=50&data=0&peak=false");
            assertEquals(200, conn.getResponseCode());
            String body = leerCuerpo(conn);
            // charge es un número JSON (sin comillas): "charge":0.00
            assertTrue(body.contains("\"charge\":0.00"), "body: " + body);
        }

        @Test
        @DisplayName("GET con plan desconocido retorna 400 con campo error")
        void planDesconocido_retorna400() throws IOException {
            HttpURLConnection conn = get("/fare?plan=INEXISTENTE");
            assertEquals(400, conn.getResponseCode());
            assertTrue(leerCuerpo(conn).contains("error"));
        }

        @Test
        @DisplayName("POST retorna 405 method not allowed")
        void post_retorna405_methodNotAllowed() throws IOException {
            URL url = new URL("http://127.0.0.1:" + port + "/fare");
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setDoOutput(true);
            conn.getOutputStream().write(new byte[0]);

            assertEquals(405, conn.getResponseCode());
        }
    }

    // =========================================================================
    // /discount
    // =========================================================================

    @Nested
    @DisplayName("/discount")
    class Discount {

        @Test
        @DisplayName("GET customerId=C1 (SILVER) amount=100 — 100 - 5% = 95.00")
        void silver_descuento5pct_retorna9500() throws IOException {
            HttpURLConnection conn = get("/discount?customerId=C1&amount=100");
            assertEquals(200, conn.getResponseCode());
            String body = leerCuerpo(conn);
            // finalAmount es un número JSON (sin comillas): "finalAmount":95.00
            assertTrue(body.contains("\"finalAmount\":95.00"), "body: " + body);
        }

        @Test
        @DisplayName("GET customerId=C2 (GOLD) amount=100 — 100 - 10% = 90.00")
        void gold_descuento10pct_retorna9000() throws IOException {
            HttpURLConnection conn = get("/discount?customerId=C2&amount=100");
            assertEquals(200, conn.getResponseCode());
            String body = leerCuerpo(conn);
            // finalAmount es un número JSON (sin comillas): "finalAmount":90.00
            assertTrue(body.contains("\"finalAmount\":90.00"), "body: " + body);
        }

        @Test
        @DisplayName("GET customerId=C3 (PLATINUM) amount=100 — 100 - 15% = 85.00")
        void platinum_descuento15pct_retorna8500() throws IOException {
            HttpURLConnection conn = get("/discount?customerId=C3&amount=100");
            assertEquals(200, conn.getResponseCode());
            String body = leerCuerpo(conn);
            // finalAmount es un número JSON (sin comillas): "finalAmount":85.00
            assertTrue(body.contains("\"finalAmount\":85.00"), "body: " + body);
        }

        @Test
        @DisplayName("GET sin customerId retorna 400")
        void sinCustomerId_retorna400() throws IOException {
            HttpURLConnection conn = get("/discount?amount=100");
            assertEquals(400, conn.getResponseCode());
            assertTrue(leerCuerpo(conn).contains("error"));
        }

        @Test
        @DisplayName("GET con amount=0 retorna 400 (monto no positivo)")
        void amountCero_retorna400() throws IOException {
            HttpURLConnection conn = get("/discount?customerId=C1&amount=0");
            assertEquals(400, conn.getResponseCode());
            assertTrue(leerCuerpo(conn).contains("error"));
        }

        @Test
        @DisplayName("POST retorna 405 method not allowed")
        void post_retorna405_methodNotAllowed() throws IOException {
            URL url = new URL("http://127.0.0.1:" + port + "/discount");
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setDoOutput(true);
            conn.getOutputStream().write(new byte[0]);

            assertEquals(405, conn.getResponseCode());
        }
    }

    // =========================================================================
    // /  (raíz)
    // =========================================================================

    @Nested
    @DisplayName("/ (raíz)")
    class Root {

        @Test
        @DisplayName("GET / retorna 200 con lista de endpoints conocidos")
        void get_raiz_retorna200_conEndpoints() throws IOException {
            HttpURLConnection conn = get("/");
            assertEquals(200, conn.getResponseCode());
            String body = leerCuerpo(conn);
            assertTrue(body.contains("claro-lab-api"), "body: " + body);
            assertTrue(body.contains("/health"),       "body: " + body);
            assertTrue(body.contains("/fare"),         "body: " + body);
            assertTrue(body.contains("/discount"),     "body: " + body);
        }

        @Test
        @DisplayName("GET a ruta inexistente retorna 404")
        void rutaInexistente_retorna404() throws IOException {
            // El contexto "/" captura todas las sub-rutas no registradas
            HttpURLConnection conn = get("/no-existe");
            assertEquals(404, conn.getResponseCode());
            assertTrue(leerCuerpo(conn).contains("not found"));
        }
    }
}
