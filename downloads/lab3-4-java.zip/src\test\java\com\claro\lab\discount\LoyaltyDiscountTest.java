package com.claro.lab.discount;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
@DisplayName("LoyaltyDiscount")
class LoyaltyDiscountTest {

    @Mock
    LoyaltyTierLookup tierLookup;

    LoyaltyDiscount subject;

    @BeforeEach
    void setUp() {
        subject = new LoyaltyDiscount(tierLookup);
    }

    // -------------------------------------------------------------------------
    // Constructor
    // -------------------------------------------------------------------------

    @Nested
    @DisplayName("Constructor")
    class Constructor {

        @Test
        @DisplayName("tierLookup nulo en constructor lanza NullPointerException")
        void nullTierLookup_throwsNullPointerException() {
            assertThatThrownBy(() -> new LoyaltyDiscount(null))
                    .isInstanceOf(NullPointerException.class);
        }
    }

    // -------------------------------------------------------------------------
    // Tasas por nivel
    // -------------------------------------------------------------------------

    @Nested
    @DisplayName("Descuento por nivel de lealtad")
    class DescuentoPorNivel {

        @Test
        @DisplayName("NONE: sin descuento, devuelve monto original")
        void none_noDiscount_returnsOriginalAmount() {
            when(tierLookup.findTier("C0")).thenReturn(LoyaltyTier.NONE);
            BigDecimal result = subject.apply("C0", new BigDecimal("100.00"));
            assertThat(result).isEqualByComparingTo("100.00");
        }

        @Test
        @DisplayName("SILVER: descuento del 5% sobre el monto")
        void silver_applies5PercentDiscount() {
            when(tierLookup.findTier("C1")).thenReturn(LoyaltyTier.SILVER);
            BigDecimal result = subject.apply("C1", new BigDecimal("200.00"));
            // 200 × 0.05 = 10 → 200 - 10 = 190
            assertThat(result).isEqualByComparingTo("190.00");
        }

        @Test
        @DisplayName("GOLD: descuento del 10% sobre el monto")
        void gold_applies10PercentDiscount() {
            when(tierLookup.findTier("C2")).thenReturn(LoyaltyTier.GOLD);
            BigDecimal result = subject.apply("C2", new BigDecimal("200.00"));
            // 200 × 0.10 = 20 → 200 - 20 = 180
            assertThat(result).isEqualByComparingTo("180.00");
        }

        @Test
        @DisplayName("PLATINUM: descuento del 15% sobre monto pequeño")
        void platinum_applies15PercentDiscount() {
            when(tierLookup.findTier("C3")).thenReturn(LoyaltyTier.PLATINUM);
            BigDecimal result = subject.apply("C3", new BigDecimal("100.00"));
            // 100 × 0.15 = 15 → 100 - 15 = 85
            assertThat(result).isEqualByComparingTo("85.00");
        }
    }

    // -------------------------------------------------------------------------
    // Tope de descuento
    // -------------------------------------------------------------------------

    @Nested
    @DisplayName("Tope de descuento en 50.00")
    class TopeDescuento {

        @Test
        @DisplayName("PLATINUM con monto 500: descuento 75 > 50 → aplicado como 50")
        void platinum_amountOver333_discountCappedAt50() {
            when(tierLookup.findTier("C3")).thenReturn(LoyaltyTier.PLATINUM);
            BigDecimal result = subject.apply("C3", new BigDecimal("500.00"));
            // 500 × 0.15 = 75 → min(75, 50) = 50 → 500 - 50 = 450
            assertThat(result).isEqualByComparingTo("450.00");
        }

        @Test
        @DisplayName("GOLD con monto 600: descuento 60 > 50 → aplicado como 50")
        void gold_amountOver500_discountCappedAt50() {
            when(tierLookup.findTier("C2")).thenReturn(LoyaltyTier.GOLD);
            BigDecimal result = subject.apply("C2", new BigDecimal("600.00"));
            // 600 × 0.10 = 60 → min(60, 50) = 50 → 600 - 50 = 550
            assertThat(result).isEqualByComparingTo("550.00");
        }

        @Test
        @DisplayName("SILVER con monto 1100: descuento 55 > 50 → aplicado como 50")
        void silver_amountOver1000_discountCappedAt50() {
            when(tierLookup.findTier("C1")).thenReturn(LoyaltyTier.SILVER);
            BigDecimal result = subject.apply("C1", new BigDecimal("1100.00"));
            // 1100 × 0.05 = 55 → min(55, 50) = 50 → 1100 - 50 = 1050
            assertThat(result).isEqualByComparingTo("1050.00");
        }
    }

    // -------------------------------------------------------------------------
    // Validaciones de customerId
    // -------------------------------------------------------------------------

    @Nested
    @DisplayName("Validaciones de customerId")
    class ValidacionesCustomerId {

        @Test
        @DisplayName("customerId nulo lanza IllegalArgumentException")
        void nullCustomerId_throwsIllegalArgumentException() {
            assertThatThrownBy(() -> subject.apply(null, new BigDecimal("100.00")))
                    .isInstanceOf(IllegalArgumentException.class);
        }

        @ParameterizedTest
        @ValueSource(strings = {"", "   "})
        @DisplayName("customerId vacío o en blanco lanza IllegalArgumentException")
        void blankCustomerId_throwsIllegalArgumentException(String blankId) {
            assertThatThrownBy(() -> subject.apply(blankId, new BigDecimal("100.00")))
                    .isInstanceOf(IllegalArgumentException.class);
        }
    }

    // -------------------------------------------------------------------------
    // Validaciones de amount
    // -------------------------------------------------------------------------

    @Nested
    @DisplayName("Validaciones de amount")
    class ValidacionesAmount {

        @Test
        @DisplayName("amount nulo lanza NullPointerException")
        void nullAmount_throwsNullPointerException() {
            assertThatThrownBy(() -> subject.apply("C1", null))
                    .isInstanceOf(NullPointerException.class);
        }

        @Test
        @DisplayName("amount cero lanza IllegalArgumentException")
        void zeroAmount_throwsIllegalArgumentException() {
            assertThatThrownBy(() -> subject.apply("C1", BigDecimal.ZERO))
                    .isInstanceOf(IllegalArgumentException.class);
        }

        @Test
        @DisplayName("amount negativo lanza IllegalArgumentException")
        void negativeAmount_throwsIllegalArgumentException() {
            assertThatThrownBy(() -> subject.apply("C1", new BigDecimal("-50.00")))
                    .isInstanceOf(IllegalArgumentException.class);
        }
    }

    // -------------------------------------------------------------------------
    // tierLookup devuelve null
    // -------------------------------------------------------------------------

    @Nested
    @DisplayName("tierLookup devuelve null")
    class TierLookupReturnNull {

        @Test
        @DisplayName("tierLookup devuelve null lanza NullPointerException")
        void tierLookupReturnsNull_throwsNullPointerException() {
            when(tierLookup.findTier("C9")).thenReturn(null);
            assertThatThrownBy(() -> subject.apply("C9", new BigDecimal("100.00")))
                    .isInstanceOf(NullPointerException.class);
        }
    }

    // -------------------------------------------------------------------------
    // discountRate directo
    // -------------------------------------------------------------------------

    @Nested
    @DisplayName("discountRate por nivel")
    class DiscountRatePorNivel {

        @Test
        @DisplayName("NONE → tasa 0")
        void none_rateIsZero() {
            assertThat(subject.discountRate(LoyaltyTier.NONE))
                    .isEqualByComparingTo("0");
        }

        @Test
        @DisplayName("SILVER → tasa 0.05")
        void silver_rateIs005() {
            assertThat(subject.discountRate(LoyaltyTier.SILVER))
                    .isEqualByComparingTo("0.05");
        }

        @Test
        @DisplayName("GOLD → tasa 0.10")
        void gold_rateIs010() {
            assertThat(subject.discountRate(LoyaltyTier.GOLD))
                    .isEqualByComparingTo("0.10");
        }

        @Test
        @DisplayName("PLATINUM → tasa 0.15")
        void platinum_rateIs015() {
            assertThat(subject.discountRate(LoyaltyTier.PLATINUM))
                    .isEqualByComparingTo("0.15");
        }

        @Test
        @DisplayName("tier nulo en discountRate lanza NullPointerException")
        void nullTier_throwsNullPointerException() {
            assertThatThrownBy(() -> subject.discountRate(null))
                    .isInstanceOf(NullPointerException.class);
        }
    }
}
