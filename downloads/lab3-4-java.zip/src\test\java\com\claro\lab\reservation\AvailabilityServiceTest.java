package com.claro.lab.reservation;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

import java.time.LocalDate;
import java.time.LocalDateTime;

import static org.junit.jupiter.api.Assertions.*;

@DisplayName("AvailabilityService")
class AvailabilityServiceTest {

    private AvailabilityService service;

    /** Martes 10:00 — dentro del horario laboral (09:00–18:00) */
    private static final LocalDateTime SLOT_10AM =
            LocalDate.of(2024, 6, 11).atTime(10, 0);

    @BeforeEach
    void setUp() {
        service = new AvailabilityService();
    }

    // -------------------------------------------------------------------------
    // isAvailable — validaciones de entrada
    // -------------------------------------------------------------------------

    @Nested
    @DisplayName("isAvailable — validaciones de parámetros")
    class IsAvailableValidation {

        @Test
        @DisplayName("storeId nulo lanza IllegalArgumentException")
        void nullStoreId_throwsIllegalArgumentException() {
            assertThrows(IllegalArgumentException.class,
                    () -> service.isAvailable(null, SLOT_10AM, 30));
        }

        @Test
        @DisplayName("storeId vacío lanza IllegalArgumentException")
        void blankStoreId_throwsIllegalArgumentException() {
            assertThrows(IllegalArgumentException.class,
                    () -> service.isAvailable("   ", SLOT_10AM, 30));
        }

        @Test
        @DisplayName("slotStart nulo lanza NullPointerException")
        void nullSlotStart_throwsNullPointerException() {
            assertThrows(NullPointerException.class,
                    () -> service.isAvailable("STORE-1", null, 30));
        }

        @ParameterizedTest(name = "durationMinutes={0} lanza IllegalArgumentException")
        @ValueSource(ints = {14, 0, -1, 121, 200})
        @DisplayName("Duración fuera de rango [15, 120] lanza IllegalArgumentException")
        void durationOutOfRange_throwsIllegalArgumentException(int duration) {
            assertThrows(IllegalArgumentException.class,
                    () -> service.isAvailable("STORE-1", SLOT_10AM, duration));
        }
    }

    // -------------------------------------------------------------------------
    // isAvailable — horario laboral
    // -------------------------------------------------------------------------

    @Nested
    @DisplayName("isAvailable — horario laboral")
    class BusinessHours {

        @Test
        @DisplayName("Slot que empieza antes de apertura (09:00) → false")
        void slotBeforeOpenHour_returnsFalse() {
            LocalDateTime before = LocalDate.of(2024, 6, 11).atTime(8, 0);
            assertFalse(service.isAvailable("STORE-1", before, 30));
        }

        @Test
        @DisplayName("Slot que termina después del cierre (18:00) → false")
        void slotEndAfterCloseHour_returnsFalse() {
            // 17:45 + 30 min = 18:15 → fuera de horario
            LocalDateTime nearClose = LocalDate.of(2024, 6, 11).atTime(17, 45);
            assertFalse(service.isAvailable("STORE-1", nearClose, 30));
        }

        @Test
        @DisplayName("Slot que termina exactamente a las 18:00 → true")
        void slotEndExactlyAtClose_returnsTrue() {
            // 17:30 + 30 min = 18:00 → dentro de horario
            LocalDateTime atClose = LocalDate.of(2024, 6, 11).atTime(17, 30);
            assertTrue(service.isAvailable("STORE-1", atClose, 30));
        }

        @Test
        @DisplayName("Slot que cruza medianoche → false")
        void slotCrossingMidnight_returnsFalse() {
            LocalDateTime lateNight = LocalDate.of(2024, 6, 11).atTime(23, 50);
            assertFalse(service.isAvailable("STORE-1", lateNight, 30));
        }
    }

    // -------------------------------------------------------------------------
    // isAvailable — solapamientos
    // -------------------------------------------------------------------------

    @Nested
    @DisplayName("isAvailable — solapamientos")
    class OverlapBehavior {

        @Test
        @DisplayName("Slot libre sin reservas previas → true")
        void noReservations_slotIsAvailable() {
            assertTrue(service.isAvailable("STORE-1", SLOT_10AM, 30));
        }

        @Test
        @DisplayName("Solapamiento exacto retorna false")
        void exactOverlap_notAvailable() {
            service.register(new Reservation("R1", "STORE-1", SLOT_10AM, 60));
            assertFalse(service.isAvailable("STORE-1", SLOT_10AM, 30));
        }

        @Test
        @DisplayName("Solapamiento parcial al inicio → false")
        void partialOverlapAtStart_notAvailable() {
            // Reserva existente: 10:00–11:00; candidato: 09:30–10:30 (pero 09:30 < 09:00 es ok — usamos 09:30 > 09:00)
            service.register(new Reservation("R1", "STORE-1", SLOT_10AM, 60));   // 10:00–11:00
            LocalDateTime candidate = SLOT_10AM.minusMinutes(30);                 // 09:30
            assertFalse(service.isAvailable("STORE-1", candidate, 60));           // 09:30–10:30
        }

        @Test
        @DisplayName("Solapamiento parcial al final → false")
        void partialOverlapAtEnd_notAvailable() {
            service.register(new Reservation("R1", "STORE-1", SLOT_10AM, 60));   // 10:00–11:00
            LocalDateTime candidate = SLOT_10AM.plusMinutes(30);                  // 10:30
            assertFalse(service.isAvailable("STORE-1", candidate, 60));           // 10:30–11:30
        }

        @Test
        @DisplayName("Slot adyacente (empieza cuando termina otro) → true")
        void adjacentSlot_isAvailable() {
            service.register(new Reservation("R1", "STORE-1", SLOT_10AM, 60));   // 10:00–11:00
            LocalDateTime adjacent = SLOT_10AM.plusMinutes(60);                   // 11:00
            assertTrue(service.isAvailable("STORE-1", adjacent, 30));            // 11:00–11:30
        }

        @Test
        @DisplayName("Tienda diferente no causa conflicto → true")
        void differentStore_noConflict() {
            service.register(new Reservation("R1", "STORE-1", SLOT_10AM, 60));
            assertTrue(service.isAvailable("STORE-2", SLOT_10AM, 30));
        }

        @Test
        @DisplayName("storeId case-insensitive: STORE-1 y store-1 son la misma tienda")
        void storeIdCaseInsensitive_causeConflict() {
            service.register(new Reservation("R1", "STORE-1", SLOT_10AM, 60));
            assertFalse(service.isAvailable("store-1", SLOT_10AM, 30));
        }
    }

    // -------------------------------------------------------------------------
    // countForStore
    // -------------------------------------------------------------------------

    @Nested
    @DisplayName("countForStore")
    class CountForStore {

        @Test
        @DisplayName("Sin reservas: retorna 0")
        void noReservations_returnsZero() {
            assertEquals(0, service.countForStore("STORE-1"));
        }

        @Test
        @DisplayName("Con reservas: retorna conteo correcto")
        void withReservations_returnsCorrectCount() {
            LocalDateTime slot2 = SLOT_10AM.plusHours(2); // 12:00
            service.register(new Reservation("R1", "STORE-1", SLOT_10AM, 30));
            service.register(new Reservation("R2", "STORE-1", slot2, 30));
            service.register(new Reservation("R3", "STORE-2", SLOT_10AM, 30));

            assertEquals(2, service.countForStore("STORE-1"));
            assertEquals(1, service.countForStore("STORE-2"));
        }

        @Test
        @DisplayName("storeId nulo lanza IllegalArgumentException")
        void nullStoreId_throwsIllegalArgumentException() {
            assertThrows(IllegalArgumentException.class,
                    () -> service.countForStore(null));
        }

        @Test
        @DisplayName("storeId vacío lanza IllegalArgumentException")
        void blankStoreId_throwsIllegalArgumentException() {
            assertThrows(IllegalArgumentException.class,
                    () -> service.countForStore("  "));
        }
    }

    // -------------------------------------------------------------------------
    // register
    // -------------------------------------------------------------------------

    @Nested
    @DisplayName("register")
    class Register {

        @Test
        @DisplayName("reservation nula lanza NullPointerException")
        void nullReservation_throwsNullPointerException() {
            assertThrows(NullPointerException.class,
                    () -> service.register(null));
        }
    }
}
