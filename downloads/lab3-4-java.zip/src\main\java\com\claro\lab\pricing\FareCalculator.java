package com.claro.lab.pricing;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Objects;

/**
 * Calcula el cargo por consumo de minutos y datos móviles según plan y franja horaria.
 * Reglas de negocio pensadas para ejercitar ramas, bordes y validaciones en unit tests.
 */
public class FareCalculator {

    public enum PlanType {
        PREPAID,
        POSTPAID,
        CORPORATE
    }

    private static final BigDecimal PREPAID_MINUTE = new BigDecimal("0.45");
    private static final BigDecimal POSTPAID_MINUTE = new BigDecimal("0.30");
    private static final BigDecimal CORPORATE_MINUTE = new BigDecimal("0.18");

    private static final BigDecimal DATA_MB_RATE = new BigDecimal("0.08");
    private static final BigDecimal PEAK_MULTIPLIER = new BigDecimal("1.25");
    private static final BigDecimal FREE_MINUTES_CORPORATE = new BigDecimal("100");
    private static final BigDecimal FREE_DATA_MB_POSTPAID = new BigDecimal("500");

    /**
     * Calcula el cargo total por minutos y datos consumidos.
     *
     * @param planType      tipo de plan del cliente
     * @param minutesUsed   minutos de voz (puede ser 0)
     * @param dataMbUsed    megabytes de datos (puede ser 0)
     * @param peakHours     true si el consumo ocurrió en horario pico
     * @return cargo redondeado a 2 decimales
     * @throws IllegalArgumentException si los parámetros son inválidos
     */
    public BigDecimal calculate(PlanType planType, int minutesUsed, int dataMbUsed, boolean peakHours) {
        Objects.requireNonNull(planType, "planType es obligatorio");
        if (minutesUsed < 0) {
            throw new IllegalArgumentException("minutesUsed no puede ser negativo: " + minutesUsed);
        }
        if (dataMbUsed < 0) {
            throw new IllegalArgumentException("dataMbUsed no puede ser negativo: " + dataMbUsed);
        }

        BigDecimal voiceCharge = voiceCharge(planType, minutesUsed);
        BigDecimal dataCharge = dataCharge(planType, dataMbUsed);
        BigDecimal subtotal = voiceCharge.add(dataCharge);

        if (peakHours && subtotal.compareTo(BigDecimal.ZERO) > 0) {
            subtotal = subtotal.multiply(PEAK_MULTIPLIER);
        }

        return subtotal.setScale(2, RoundingMode.HALF_UP);
    }

    private BigDecimal voiceCharge(PlanType planType, int minutesUsed) {
        BigDecimal billableMinutes = BigDecimal.valueOf(minutesUsed);

        if (planType == PlanType.CORPORATE) {
            billableMinutes = billableMinutes.subtract(FREE_MINUTES_CORPORATE).max(BigDecimal.ZERO);
        }

        return billableMinutes.multiply(ratePerMinute(planType));
    }

    private BigDecimal dataCharge(PlanType planType, int dataMbUsed) {
        BigDecimal billableMb = BigDecimal.valueOf(dataMbUsed);

        if (planType == PlanType.POSTPAID) {
            billableMb = billableMb.subtract(FREE_DATA_MB_POSTPAID).max(BigDecimal.ZERO);
        }

        if (planType == PlanType.CORPORATE && dataMbUsed > 0) {
            // Corporativo: 15% de descuento en datos facturables
            return billableMb.multiply(DATA_MB_RATE).multiply(new BigDecimal("0.85"));
        }

        return billableMb.multiply(DATA_MB_RATE);
    }

    private BigDecimal ratePerMinute(PlanType planType) {
        return switch (planType) {
            case PREPAID -> PREPAID_MINUTE;
            case POSTPAID -> POSTPAID_MINUTE;
            case CORPORATE -> CORPORATE_MINUTE;
        };
    }
}
