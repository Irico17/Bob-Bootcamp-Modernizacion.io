package com.claro.lab.discount;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

@DisplayName("InMemoryLoyaltyTierLookup")
class InMemoryLoyaltyTierLookupTest {

    private InMemoryLoyaltyTierLookup lookup;

    @BeforeEach
    void setUp() {
        lookup = new InMemoryLoyaltyTierLookup();
    }

    @Nested
    @DisplayName("Datos precargados")
    class DatosPrecargados {

        @Test
        @DisplayName("C1 devuelve SILVER")
        void c1_returnsSilver() {
            assertThat(lookup.findTier("C1")).isEqualTo(LoyaltyTier.SILVER);
        }

        @Test
        @DisplayName("C2 devuelve GOLD")
        void c2_returnsGold() {
            assertThat(lookup.findTier("C2")).isEqualTo(LoyaltyTier.GOLD);
        }

        @Test
        @DisplayName("C3 devuelve PLATINUM")
        void c3_returnsPlatinum() {
            assertThat(lookup.findTier("C3")).isEqualTo(LoyaltyTier.PLATINUM);
        }
    }

    @Nested
    @DisplayName("ID desconocido")
    class IdDesconocido {

        @Test
        @DisplayName("ID sin registro devuelve NONE")
        void unknownId_returnsNone() {
            assertThat(lookup.findTier("X99")).isEqualTo(LoyaltyTier.NONE);
        }
    }

    @Nested
    @DisplayName("Normalización y validaciones")
    class NormalizacionYValidaciones {

        @Test
        @DisplayName("ID con espacios ' C1 ' devuelve SILVER tras trim()")
        void paddedId_normalizedWithTrim() {
            assertThat(lookup.findTier(" C1 ")).isEqualTo(LoyaltyTier.SILVER);
        }

        @Test
        @DisplayName("customerId nulo lanza IllegalArgumentException")
        void nullCustomerId_throwsIllegalArgumentException() {
            assertThatThrownBy(() -> lookup.findTier(null))
                    .isInstanceOf(IllegalArgumentException.class);
        }

        @ParameterizedTest
        @ValueSource(strings = {"", "   "})
        @DisplayName("customerId en blanco lanza IllegalArgumentException")
        void blankCustomerId_throwsIllegalArgumentException(String blankId) {
            assertThatThrownBy(() -> lookup.findTier(blankId))
                    .isInstanceOf(IllegalArgumentException.class);
        }
    }
}
