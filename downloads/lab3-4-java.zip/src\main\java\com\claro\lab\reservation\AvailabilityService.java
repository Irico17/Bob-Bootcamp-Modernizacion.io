package com.claro.lab.reservation;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 * Verifica disponibilidad de slots para reservas en tienda.
 * Incluye validaciones y solapamientos como buenos candidatos a unit test.
 */
public class AvailabilityService {

    private static final int MIN_DURATION = 15;
    private static final int MAX_DURATION = 120;
    private static final int OPEN_HOUR = 9;
    private static final int CLOSE_HOUR = 18;

    private final List<Reservation> existing = new ArrayList<>();

    public void register(Reservation reservation) {
        Objects.requireNonNull(reservation, "reservation");
        existing.add(reservation);
    }

    /**
     * Indica si se puede reservar el slot solicitado en la tienda.
     *
     * @throws IllegalArgumentException si los parámetros son inválidos
     */
    public boolean isAvailable(String storeId, LocalDateTime slotStart, int durationMinutes) {
        if (storeId == null || storeId.isBlank()) {
            throw new IllegalArgumentException("storeId es obligatorio");
        }
        Objects.requireNonNull(slotStart, "slotStart es obligatorio");
        if (durationMinutes < MIN_DURATION || durationMinutes > MAX_DURATION) {
            throw new IllegalArgumentException(
                    "durationMinutes debe estar entre " + MIN_DURATION + " y " + MAX_DURATION);
        }
        if (!withinBusinessHours(slotStart, durationMinutes)) {
            return false;
        }

        Reservation candidate = new Reservation("candidate", storeId.trim(), slotStart, durationMinutes);
        return existing.stream()
                .filter(r -> r.getStoreId().equalsIgnoreCase(storeId.trim()))
                .noneMatch(candidate::overlaps);
    }

    private boolean withinBusinessHours(LocalDateTime start, int durationMinutes) {
        LocalDateTime end = start.plusMinutes(durationMinutes);
        if (start.getHour() < OPEN_HOUR) {
            return false;
        }
        // Debe terminar a más tardar a la hora de cierre del mismo día
        if (end.toLocalDate().isAfter(start.toLocalDate())) {
            return false;
        }
        return !end.isAfter(start.toLocalDate().atTime(CLOSE_HOUR, 0));
    }

    public int countForStore(String storeId) {
        if (storeId == null || storeId.isBlank()) {
            throw new IllegalArgumentException("storeId es obligatorio");
        }
        String normalized = storeId.trim();
        return (int) existing.stream()
                .filter(r -> r.getStoreId().equalsIgnoreCase(normalized))
                .count();
    }
}
