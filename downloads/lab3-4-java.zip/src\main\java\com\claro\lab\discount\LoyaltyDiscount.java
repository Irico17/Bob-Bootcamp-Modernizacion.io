package com.claro.lab.discount;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Objects;

/**
 * Aplica descuento por lealtad sobre un monto base.
 * Depende de {@link LoyaltyTierLookup} para justificar Mockito en el lab.
 */
public class LoyaltyDiscount {

    private static final BigDecimal SILVER_RATE = new BigDecimal("0.05");
    private static final BigDecimal GOLD_RATE = new BigDecimal("0.10");
    private static final BigDecimal PLATINUM_RATE = new BigDecimal("0.15");
    private static final BigDecimal MAX_DISCOUNT = new BigDecimal("50.00");

    private final LoyaltyTierLookup tierLookup;

    public LoyaltyDiscount(LoyaltyTierLookup tierLookup) {
        this.tierLookup = Objects.requireNonNull(tierLookup, "tierLookup es obligatorio");
    }

    /**
     * Calcula el monto final tras aplicar el descuento de lealtad.
     *
     * @param customerId identificador del cliente
     * @param amount     monto base (&gt; 0)
     * @return monto final redondeado a 2 decimales
     * @throws IllegalArgumentException si customerId o amount son inválidos
     */
    public BigDecimal apply(String customerId, BigDecimal amount) {
        if (customerId == null || customerId.isBlank()) {
            throw new IllegalArgumentException("customerId es obligatorio");
        }
        Objects.requireNonNull(amount, "amount es obligatorio");
        if (amount.compareTo(BigDecimal.ZERO) <= 0) {
            throw new IllegalArgumentException("amount debe ser mayor que cero: " + amount);
        }

        LoyaltyTier tier = tierLookup.findTier(customerId.trim());
        Objects.requireNonNull(tier, "tierLookup devolvió null para " + customerId);

        BigDecimal rate = discountRate(tier);
        if (rate.compareTo(BigDecimal.ZERO) == 0) {
            return amount.setScale(2, RoundingMode.HALF_UP);
        }

        BigDecimal rawDiscount = amount.multiply(rate);
        BigDecimal discount = rawDiscount.min(MAX_DISCOUNT);
        return amount.subtract(discount).setScale(2, RoundingMode.HALF_UP);
    }

    /**
     * Expone la tasa aplicada por nivel (útil para asserts en tests).
     */
    public BigDecimal discountRate(LoyaltyTier tier) {
        Objects.requireNonNull(tier, "tier es obligatorio");
        return switch (tier) {
            case NONE -> BigDecimal.ZERO;
            case SILVER -> SILVER_RATE;
            case GOLD -> GOLD_RATE;
            case PLATINUM -> PLATINUM_RATE;
        };
    }
}
