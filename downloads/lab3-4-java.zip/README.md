# Lab Bob Premium — Java Unit Testing (15–20 min)

Laboratorio corto para demostrar **Bob Premium Java Unit Testing** sobre un dominio de precios, lealtad y reservas en tienda (estilo Claro / telecom). El código de producción está listo; **los tests, JaCoCo y el diagrama del proceso los genera Bob** durante el demo.

---

## 1. Explicación de la aplicación

Aplicación demo Maven (Java 17) con lógica de negocio típica de un operador móvil: tarifas por plan, descuentos por lealtad y disponibilidad de citas en tienda. Incluye una **capa HTTP mínima** (servidor del JDK, sin frameworks) para poder contenerizar y levantar la app en el **[Lab 4](LAB4-CONTENERIZACION.md)**. No hay UI ni base de datos: el valor del Lab 3 está en las **ramas, validaciones y dependencias inyectables** que Bob debe cubrir con unit tests.

| Paquete / clase | Qué hace |
|-----------------|----------|
| **`pricing.FareCalculator`** | Calcula el cargo por minutos y datos según plan (`PREPAID`, `POSTPAID`, `CORPORATE`), minutos/datos gratis, multiplicador de horario pico y redondeo a 2 decimales. Muchas ramas y bordes. |
| **`discount.LoyaltyDiscount`** | Aplica descuento por nivel de lealtad (Silver / Gold / Platinum) con tope máximo. Depende de `LoyaltyTierLookup` → ideal para **Mockito**. |
| **`discount.LoyaltyTier` / `LoyaltyTierLookup`** | Enum de niveles e interfaz inyectable para obtener el tier del cliente. |
| **`discount.InMemoryLoyaltyTierLookup`** | Implementación en memoria (sin BD/API) para ejecutar `/discount` en el Lab 4. |
| **`reservation.Reservation`** | Modelo de reserva en tienda (inicio, duración, solapamiento de intervalos). |
| **`reservation.AvailabilityService`** | Verifica si un slot está libre: horario comercial, duración válida y solapes con reservas existentes. |
| **`api.App`** | Servidor HTTP embebido del JDK: `GET /health`, `/fare`, `/discount`. Base ejecutable del Lab 4. |

> **Nota Lab 3:** el foco pedagógico son las clases de **negocio** (`FareCalculator`, `LoyaltyDiscount`, reservas). `App` e `InMemoryLoyaltyTierLookup` **no traen tests propios** en el baseline. Si en Select Tasks eliges **"All classes"**, Bob *puede* generar tests también para la capa HTTP (unos extras, no rompe el lab). Si quieres acotar tiempo, prioriza las clases de negocio.

---

## 2. Objetivo del laboratorio

En 15–20 minutos, ejecutar el workflow **Java Unit Testing** de Bob Premium y comprobar que:

1. Instala/configura **JaCoCo** si falta.
2. Genera una **estrategia de unit tests** (`UNITTEST.md`).
3. Crea y ejecuta tests (ciclo generate–run–fix) con subagentes.
4. Mide **cobertura** y produce un **diagrama del proceso** (Mermaid / PNG).

Al final, el proyecto pasa de **0 tests** a una suite JUnit 5 (+ Mockito) con cobertura reportable.

---

## 3. Qué es Java Unit Testing (Bob Premium)

No es “pídele al chat que escriba tests”. Es un workflow **strategy-first** del Premium Package for Java Modernization:

- **Task 0** — subagente instala **JaCoCo** en el `pom.xml` si no está.
- **Task 1** — otro subagente analiza el proyecto y genera **`UNITTEST.md`** (estrategia).
- **Select Tasks** — eliges qué sigue (generar tests, cobertura, git flow, etc.).
- Subagentes **generan, ejecutan y corrigen** tests.
- Bob produce un **grafo del proceso** (Mermaid / PNG) con pasos, clases cubiertas y (opcionalmente) costos.

---

## 4. Por qué es importante usarlo

| Enfoque chat “escribe tests” | Workflow Java Unit Testing |
|------------------------------|----------------------------|
| Tests sueltos, sin plan | Estrategia documentada (`UNITTEST.md`) |
| Sin cobertura integrada | JaCoCo + reporte de cobertura |
| Un solo agente / un shot | Subagentes por tarea, generate–run–fix |
| Difícil de repetir en modernización | Red de seguridad para refactors / Java upgrades |

En modernización, los unit tests son el **safety net**: demuestras que el comportamiento no se rompió. Bob industrializa ese paso con estrategia, cobertura y trazabilidad del proceso.

---

## 5. Prerrequisitos

| Requisito | Notas |
|-----------|--------|
| **Bob ≥ 2.0** | IDE / agente con soporte de workflows |
| **Premium Package — Java Modernization** | Incluye Java Unit Testing |
| **JDK 17** | Compilación y tests |
| **Apache Maven 3.8+** | Build del proyecto |

Documentación oficial:

- [IBM Bob Java (GitHub)](https://github.com/IBM/ibm-bob-java)
- [Java Modernization — producto](https://www.ibm.com/products/ai-coding-agent/java-modernization)
- [Getting started — Java Modernization](https://bob.ibm.com/docs/ide/premium-packages/java-modernization/getting-started)
- [Anuncio Premium Package for Java](https://bob.ibm.com/blog/pp_for_java_announcement/)

---

## 6. Cómo clonar / abrir el proyecto

```bash
git clone https://github.ibm.com/Cristhofer-Alegre/Laboratorio-Java-Unit-Test.git
cd Laboratorio-Java-Unit-Test
```

Luego:

1. Abre la carpeta del lab en Bob / Cursor.
2. Confirma que ves `pom.xml` y `src/main/java/com/claro/lab/`.
3. En la raíz del proyecto:

```bash
mvn -q test-compile
```

Debe terminar sin errores (compila main + classpath de test; **aún no hay tests** en el commit base).

---

## 7. Commit base / reset (re-ejecutar el lab)

El commit de baseline (código de negocio + capa HTTP del Lab 4 + guías, **sin tests ni JaCoCo**) es:

| Campo | Valor |
|-------|--------|
| **Mensaje** | `LaboratorioBasev1` |

Sirve para volver al estado “antes de Bob” (Lab 3) y repetir el workflow cuantas veces quieras, **conservando** el README actual, `LAB4-CONTENERIZACION.md` y la capa `api.App`.

```bash
# Ver estado actual
git status
git log -1 --oneline   # debería mostrar LaboratorioBasev1

# Descartar cambios de Bob y volver al baseline
# ⚠️ Esto elimina tests generados, UNITTEST.md, JaCoCo en pom.xml, Dockerfile, etc.
git reset --hard :/LaboratorioBasev1

# Si quedaron archivos no rastreados (tests, UNITTEST.md, etc.):
git clean -fd   # solo si estás seguro
```

> No uses el commit viejo `LaboratorioBasev0` (`e37f884`): tiene el README anterior, `GUIA-WORKFLOW.md` y **no** incluye la capa HTTP ni el Lab 4.

---

## 8. Baseline (antes de Bob)

```bash
mvn test
```

Resultado esperado: **0 tests ejecutados** (`src/test/java` vacío a propósito). En el `pom.xml` **no hay JaCoCo** todavía. Esa es la foto “antes” del lab.

---

## 9. Cómo invocar el workflow de Java Unit Testing

### 9.1 Arrancar el workflow

Elige **una** de estas formas:

1. **UI:** Start Workflow → **Java Modernization** → **Java Unit Testing**
2. **Comando:** `/start-java-mod` y continúa con Unit Testing
3. **Chat:** escribe `Java Unit Testing` (o el nombre exacto del workflow en tu build)

### 9.2 Lo que ocurre primero (automático)

Antes de la pantalla de selección, Bob suele lanzar subagentes:

1. **Task 0 — Install JaCoCo** — si falta el plugin, lo agrega al `pom.xml` y verifica el build.
2. **Task 1 — Unit Test Strategy** — analiza el proyecto y genera / actualiza **`UNITTEST.md`**.

### 9.3 Pantalla **Select Tasks**

Después aparece **Select Tasks**. Opciones típicas (documentadas según una corrida real del lab):

| Opción | Qué hace | Recomendación lab |
|--------|----------|-------------------|
| **Re-generate Unit Test Strategy** | Produce un nuevo `UNITTEST.md` aunque ya exista (toggle). | **OFF** si la estrategia ya se generó en Task 1. |
| **Generate Unit Tests** | Crea o actualiza unit tests según la estrategia actual. | **ON** |
| **Candidate Selection Strategy** *(requerido)* | Dropdown de alcance. En el lab se vio **"All classes"**. | **"All classes"** funciona bien en este proyecto pequeño. Si hay opción más enfocada y el tiempo aprieta, úsala; si no, All classes está bien. |
| **Run Code Coverage** | Mide cobertura y reporta (capacidad clave de Bob). | **ON** |
| **Enable Git Flow** | Auto-commit a una rama nueva en pasos clave. | **OFF** (facilita resets al baseline). |

Confirma la selección y continúa.

### 9.4 Qué sigue

Bob lanza subagentes que:

- Generan tests por clase / grupo.
- Los ejecutan y corrigen (ciclo **generate → run → fix**).
- Configuran / usan JaCoCo para cobertura.
- Generan un **diagrama del proceso** (Mermaid y/o **PNG**) con el flujo completo.

Al terminar, revisa artefactos (sección 10–11) y valida con `mvn test`.

---

## 10. Qué revisar y probar

- **`UNITTEST.md`** — estrategia: stack (JUnit 5, Mockito), clases objetivo, enfoque por grupos.
- **Tests en `src/test/java/...`** — asserts, mocks de `LoyaltyTierLookup`, bordes (negativos, `null`, tope de descuento, minutos gratis corporativos, solapes de reserva).
- **JaCoCo en `pom.xml`** — Bob lo agrega; no está en el commit base a propósito.
- **Reporte de cobertura** — tras el paso de cobertura del workflow / `mvn test` (o goals de reporte que Bob deje configurados).
- **Diagrama del proceso** — PNG / Mermaid generado por Bob.
- **Sanity check:** altera a propósito una regla de negocio y confirma que algún test falla (no merges ciegos).

```bash
mvn test
```

---

## 11. Resultados esperados

Tras una corrida exitosa deberías ver:

| Artefacto | Descripción |
|-----------|-------------|
| `UNITTEST.md` | Estrategia de unit tests |
| `pom.xml` | Plugin JaCoCo (p. ej. `jacoco-maven-plugin`) |
| `src/test/java/...` | Suites JUnit 5 (+ Mockito donde aplique) |
| Cobertura | Reporte / métricas de cobertura |
| Diagrama del proceso | Grafo Mermaid y/o PNG del workflow |

Los números exactos (cantidad de tests, líneas de `UNITTEST.md`, costos en coins) **varían por corrida**. El ejemplo siguiente es de **una** ejecución exitosa (~74 tests, cobertura alta en varias clases).

### Ejemplo de diagrama de proceso (corrida de referencia)

Bob genera un grafo similar a este (también como PNG). Inclúyelo solo como referencia visual:

```mermaid
flowchart TD
    classDef untested fill:#2a0a18,stroke:#ee5396,stroke-width:2px
    classDef tested fill:#081a1c,stroke:#009d9a,stroke-width:2px
    classDef process fill:#001141,stroke:#4589ff,stroke-width:2px,text-align:left

    start["Unit Testing Process"] --> jacoco["<b>Task 0: Install JaCoCo</b><br>- Added jacoco-maven-plugin 0.8.15 to pom.xml<br>- Configured prepare-agent and report executions<br>- Verified BUILD SUCCESS with mvn clean test"]:::process

    jacoco --> strategy["<b>Task 1: Generate Strategy</b><br>- Analyzed 6 production source files<br>- Identified test framework stack: JUnit 5.10.2, Mockito 5.11.0<br>- Created UNITTEST.md with 330-line strategy document"]:::process

    strategy --> untested1["LoyaltyDiscount<br>No tests yet"]:::untested
    strategy --> untested2["FareCalculator<br>No tests yet"]:::untested
    strategy --> untested3["Reservation<br>No tests yet"]:::untested
    strategy --> untested4["AvailabilityService<br>No tests yet"]:::untested

    untested1 --> test1["<b>Task 2: LoyaltyDiscount Tests</b><br>- 15 tests in 3 nested groups<br>- TierDiscountPaths: 5 tests for all tier paths<br>- InputValidationGuards: 6 guard tests<br>- DiscountRatePerTier: 4 rate assertions<br>- Mockito used for LoyaltyTierLookup"]:::process

    untested2 --> test2["<b>Task 3: FareCalculator Tests</b><br>- 22 tests in 5 nested groups<br>- Parameterized fare matrix: 9 rows via @MethodSource<br>- PeakMultiplier, Rounding, InputValidation groups<br>- PlanBoundaries: exact free-allowance boundary tests"]:::process

    untested3 --> test3["<b>Task 4: Reservation Tests</b><br>- 15 tests in 3 nested groups<br>- Constructor validation, getSlotEnd, overlaps<br>- Fixed anchor 2024-06-01T10:00 for overlap tests"]:::process

    untested4 --> test4["<b>Task 4: AvailabilityService Tests</b><br>- 22 tests in 4 nested groups<br>- Guards, business hours, overlap, register and count<br>- Fresh instance in @BeforeEach to prevent state pollution"]:::process

    test1 --> result1["LoyaltyDiscount<br>100% branch coverage ✅"]:::tested
    test2 --> result2["FareCalculator<br>22 tests passing ✅"]:::tested
    test3 --> result3["Reservation<br>15 tests passing ✅"]:::tested
    test4 --> result4["AvailabilityService<br>22 tests passing ✅"]:::tested

    result1 --> final["Complete Test Suite<br>74 total tests passing"]:::tested
    result2 --> final
    result3 --> final
    result4 --> final

    subgraph tasks["Task Costs"]
        direction TB
        tc0["<b>Task 0: Install JaCoCo</b><br>- Cost: 0.599946 coins<br>- Context Tokens: 59,532<br>- Cache Read: 179,543"]:::process
        tc1["<b>Task 1: Generate Strategy</b><br>- Cost: 0.759543 coins<br>- Context Tokens: 56,911<br>- Cache Read: 279,689"]:::process
        tc2["<b>Task 2: LoyaltyDiscount Tests</b><br>- Cost: 0.285647 coins<br>- Context Tokens: 29,684<br>- Cache Read: 81,662"]:::process
        tc3["<b>Task 3: FareCalculator Tests</b><br>- Cost: 0.229319 coins<br>- Context Tokens: 23,370<br>- Cache Read: 72,999"]:::process
        tc4["<b>Task 4: Reservation + AvailabilityService Tests</b><br>- Cost: 0.338328 coins<br>- Context Tokens: 25,883<br>- Cache Read: 103,124"]:::process
    end

    subgraph legend["Legend"]
        untestedExample["Untested Code"]:::untested
        processExample["Testing Step"]:::process
        testedExample["Tested Code"]:::tested
    end
```

---

## 12. Estructura del repo

```
BobClaroLaboratorioV2/
  pom.xml                          # Java 17, JAR ejecutable (app.jar), JUnit 5, Mockito — sin JaCoCo
  README.md                        # Guía Lab 3 (esta)
  LAB4-CONTENERIZACION.md          # Guía Lab 4 (contenerización K8s/OpenShift)
  src/main/java/com/claro/lab/
    api/App.java                   # HTTP /health /fare /discount (Lab 4)
    pricing/FareCalculator.java
    discount/LoyaltyDiscount.java
    discount/LoyaltyTierLookup.java
    discount/InMemoryLoyaltyTierLookup.java
    discount/LoyaltyTier.java
    reservation/AvailabilityService.java
    reservation/Reservation.java
  src/test/java/                   # vacío en LaboratorioBasev1 (0 tests)
```

Tras el Lab 3 (Bob) aparecerán, entre otros: `UNITTEST.md`, tests bajo `src/test/java/`, JaCoCo en `pom.xml` y el diagrama del proceso.

Siguiente lab: **[Lab 4 — Contenerización](LAB4-CONTENERIZACION.md)**.
