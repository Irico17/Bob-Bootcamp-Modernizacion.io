package com.claro.lab.reservation;

import java.time.LocalDateTime;
import java.util.Objects;

/**
 * Reserva simple de atención en tienda / centro de experiencia.
 */
public final class Reservation {

    private final String reservationId;
    private final String storeId;
    private final LocalDateTime slotStart;
    private final int durationMinutes;

    public Reservation(String reservationId, String storeId, LocalDateTime slotStart, int durationMinutes) {
        this.reservationId = Objects.requireNonNull(reservationId, "reservationId");
        this.storeId = Objects.requireNonNull(storeId, "storeId");
        this.slotStart = Objects.requireNonNull(slotStart, "slotStart");
        if (durationMinutes <= 0) {
            throw new IllegalArgumentException("durationMinutes debe ser positivo: " + durationMinutes);
        }
        this.durationMinutes = durationMinutes;
    }

    public String getReservationId() {
        return reservationId;
    }

    public String getStoreId() {
        return storeId;
    }

    public LocalDateTime getSlotStart() {
        return slotStart;
    }

    public int getDurationMinutes() {
        return durationMinutes;
    }

    public LocalDateTime getSlotEnd() {
        return slotStart.plusMinutes(durationMinutes);
    }

    /**
     * True si este intervalo se solapa con otro (mismo store se valida afuera).
     */
    public boolean overlaps(Reservation other) {
        Objects.requireNonNull(other, "other");
        return slotStart.isBefore(other.getSlotEnd()) && other.getSlotStart().isBefore(getSlotEnd());
    }
}
