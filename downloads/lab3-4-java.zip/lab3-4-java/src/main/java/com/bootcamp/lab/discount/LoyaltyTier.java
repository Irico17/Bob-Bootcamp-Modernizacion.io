package com.bootcamp.lab.discount;

/**
 * Nivel de lealtad del cliente en el programa de lealtad.
 */
public enum LoyaltyTier {
    NONE,
    SILVER,
    GOLD,
    PLATINUM
}
