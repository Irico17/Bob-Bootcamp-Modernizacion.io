# Lab 4 — Contenerización con Bob (Kubernetes / OpenShift) (10 min · opcional)

Laboratorio corto para demostrar cómo **Bob** ayuda a **contenerizar** una aplicación Java y generar los **artefactos de despliegue** (Dockerfile + manifiestos de Kubernetes/OpenShift) siguiendo **buenas prácticas**. Al final, de forma **opcional**, se levanta un contenedor/pod local con **Podman** (o Docker) para verificar que la imagen realmente arranca y responde.

> A diferencia del Lab 3 (unit testing), aquí el foco **no** son los tests, sino los **artefactos de contenerización** que genera Bob y la **validación** de que la app se levanta bien.

---

## 1. Objetivo del laboratorio

En ~10 minutos (laboratorio **opcional**; si el tiempo no alcanza, prioriza los pasos 1 y 2 y omite el build/run local):

1. Usar Bob para generar los artefactos de contenerización de una app Java:
   - `Dockerfile` (multi-stage, imagen slim, usuario no-root)
   - `.dockerignore`
   - Manifiestos de **Kubernetes** (`Deployment`, `Service`) y variante **OpenShift** (`Route`)
   - **Readiness / liveness probes** apuntando a `/health`
2. Revisar que Bob aplicó **buenas prácticas** (multi-stage, no-root, compatibilidad con UID aleatorio de OpenShift, límites de recursos, probes).
3. *(Opcional, si alcanza el tiempo)* Construir y **levantar la imagen localmente** con Podman/Docker y verificar `GET /health` + un endpoint de negocio.

---

## 2. Por qué esta app sí se puede "levantar"

En el Lab 3 el proyecto era una **librería** (solo lógica, sin nada que ejecutar). Para el Lab 4 se añadió una **capa HTTP mínima** (`com.claro.lab.api.App`) usando el **servidor embebido del JDK** (`com.sun.net.httpserver`), **sin dependencias nuevas**. Eso le da a la app:

- un **puerto** que exponer (8080, configurable con la variable `PORT`),
- un endpoint de **salud** (`/health`) ideal para readiness/liveness probes,
- endpoints de negocio que reutilizan la lógica del Lab 3.

| Método HTTP + ruta | Qué hace | Ejemplo |
|--------------------|----------|---------|
| `GET /health` | Estado del servicio (para probes) | `{"status":"UP"}` |
| `GET /fare` | Calcula tarifa (`FareCalculator`) | `/fare?plan=CORPORATE&minutes=150&data=800&peak=true` |
| `GET /discount` | Descuento por lealtad (`LoyaltyDiscount`) | `/discount?customerId=C2&amount=200` |
| `GET /` | Info y lista de endpoints | — |

> Clientes de ejemplo precargados para `/discount`: `C1`=SILVER, `C2`=GOLD, `C3`=PLATINUM, cualquier otro = NONE (implementados en `InMemoryLoyaltyTierLookup`, sin BD ni API externa).

### Probar la app sin contenedor (sanity check)

```bash
mvn -q -DskipTests package
java -jar target/app.jar
# en otra terminal:
curl http://localhost:8080/health
curl "http://localhost:8080/fare?plan=CORPORATE&minutes=150&data=800&peak=true"
curl "http://localhost:8080/discount?customerId=C2&amount=200"
```

Debe responder `{"status":"UP"}` y los cálculos correspondientes. Detén el proceso con `Ctrl+C`.

---

## 3. Prerrequisitos

| Requisito | Notas |
|-----------|--------|
| **Bob** | IDE / agente con acceso al proyecto |
| **JDK 17** + **Maven 3.8+** | Para compilar el `app.jar` |
| **Podman** *(preferible)* o **Docker** | Para construir y levantar la imagen local |
| *(Opcional)* `kubectl` u `oc` | Solo si se despliega en un cluster (kind / minikube / OpenShift Local) |

> No hace falta un cluster para el objetivo principal. Con Podman/Docker local basta para demostrar que la imagen se construye y arranca. Podman además puede ejecutar manifiestos de Kubernetes localmente con `podman kube play` (ver §7).

---

## 4. Cómo invocar a Bob

La contenerización se hace guiando a Bob por chat (agente). Abre el proyecto en Bob y usa prompts como los de §5. Flujo sugerido:

1. Pídele a Bob que **analice el proyecto** y detecte cómo se ejecuta (JAR ejecutable, puerto, endpoint de salud).
2. Pídele que **genere los artefactos** de contenerización (Dockerfile, `.dockerignore`, manifiestos).
3. **Revisa** que aplicó buenas prácticas (§6).
4. *(Opcional)* Pídele los **comandos** para construir y levantar la imagen con Podman/Docker.

---

## 5. Prompts guía para Bob

Cópialos/ajústalos durante el lab. Van de lo general a lo específico.

### Prompt 1 — Análisis

```text
Analiza este proyecto Maven (Java 17). Identifica:
- clase main y cómo se ejecuta (JAR ejecutable)
- puerto que expone y variable de entorno de configuración
- endpoint de health para probes
Resume cómo lo contenerizarías para Kubernetes/OpenShift.
```

### Prompt 2 — Dockerfile

```text
Genera un Dockerfile multi-stage para esta app Java 17:
- Stage de build: compila con Maven y produce el JAR ejecutable (target/app.jar).
- Stage de runtime: imagen base slim con solo JRE.
- Ejecuta como usuario NO root y compatible con el UID aleatorio de OpenShift
  (permisos de grupo 0, sin USER numérico fijo problemático).
- EXPOSE 8080, entrypoint "java -jar app.jar", respeta la variable PORT.
- Añade también un .dockerignore adecuado.
Explica brevemente cada decisión.
```

### Prompt 3 — Manifiestos Kubernetes / OpenShift

```text
Genera manifiestos para desplegar esta imagen:
- Deployment (1 réplica) con readiness y liveness probes a GET /health en el puerto 8080.
- Service (ClusterIP) que exponga el puerto.
- securityContext con buenas prácticas: runAsNonRoot, allowPrivilegeEscalation: false,
  capabilities drop ALL, seccompProfile RuntimeDefault.
- resources: requests y limits de CPU y memoria razonables.
- Variante para OpenShift: un Route que exponga el Service.
Usa labels consistentes (app=claro-lab-api).
```

### Prompt 4 *(opcional)* — Comandos de prueba local

```text
Dame los comandos para construir la imagen y levantarla localmente con Podman
(y el equivalente con Docker), incluyendo cómo verificar GET /health y detener/eliminar
el contenedor al terminar.
```

---

## 6. Buenas prácticas que Bob debe respetar (checklist de revisión)

Usa esto para validar lo que genera Bob:

- [ ] **Multi-stage build**: la imagen final **no** incluye Maven ni el JDK completo (solo JRE).
- [ ] **Imagen base slim/oficial** (p. ej. `eclipse-temurin:17-jre` o UBI de Red Hat `ubi9/openjdk-17-runtime` para OpenShift).
- [ ] **Usuario no-root** y **compatible con OpenShift** (UID arbitrario, grupo `0` con permisos, puerto > 1024 como 8080).
- [ ] `EXPOSE 8080` y respeta la variable de entorno `PORT`.
- [ ] **`.dockerignore`** excluye `target/`, `.git/`, IDE, etc. (build más rápido y limpio).
- [ ] **Probes**: readiness + liveness a `GET /health`.
- [ ] **`securityContext`**: `runAsNonRoot`, `allowPrivilegeEscalation: false`, `capabilities: drop: [ALL]`, `seccompProfile: RuntimeDefault`.
- [ ] **Límites de recursos** (`requests`/`limits` de CPU y memoria).
- [ ] **Sin secretos hardcodeados** en Dockerfile ni manifiestos.
- [ ] **Labels** consistentes (`app=claro-lab-api`).
- [ ] *(Opcional)* La etapa de build corre `mvn verify`, de modo que la imagen **solo se construye si los tests del Lab 3 pasan** (enlaza ambos labs).

---

## 7. Verificación local (opcional, si alcanza el tiempo)

### 7.1 Con Podman (preferible)

```bash
# Construir la imagen (usa el Dockerfile que generó Bob)
podman build -t claro-lab-api:1.0 .

# Levantar el contenedor
podman run -d --name claro-api -p 8080:8080 claro-lab-api:1.0

# Verificar que la app está "arriba"
curl http://localhost:8080/health
curl "http://localhost:8080/fare?plan=CORPORATE&minutes=150&data=800&peak=true"

# Ver logs y estado
podman logs claro-api
podman ps

# Limpiar al terminar
podman stop claro-api && podman rm claro-api
```

### 7.2 Con Docker (equivalente)

```bash
docker build -t claro-lab-api:1.0 .
docker run -d --name claro-api -p 8080:8080 claro-lab-api:1.0
curl http://localhost:8080/health
docker logs claro-api
docker stop claro-api && docker rm claro-api
```

### 7.3 *(Opcional)* Probar los manifiestos como pod local con Podman

Podman puede ejecutar YAML de Kubernetes sin un cluster:

```bash
podman kube play deployment.yaml        # o el nombre que use Bob
podman pod ps
curl http://localhost:8080/health
podman kube down deployment.yaml
```

### 7.4 *(Opcional)* En un cluster (kind / minikube / OpenShift Local)

```bash
kubectl apply -f deployment.yaml -f service.yaml
kubectl get pods -w                     # esperar READY 1/1
kubectl port-forward svc/claro-lab-api 8080:80
curl http://localhost:8080/health
# OpenShift: oc apply -f route.yaml && oc get route
```

---

## 8. Extra opcional — verificar tests dentro del contenedor

Si quieres conectar con el Lab 3, pídele a Bob que el **stage de build** ejecute `mvn verify`. Así, si algún unit test falla, la **imagen no se construye**. Es una forma de demostrar que la contenerización respeta la red de seguridad de tests:

```text
Modifica el Dockerfile para que el stage de build ejecute "mvn verify" (no solo package),
de modo que la imagen solo se genere si todos los unit tests pasan.
```

---

## 9. Criterios de éxito del lab

- Bob generó `Dockerfile`, `.dockerignore` y manifiestos de K8s/OpenShift.
- La revisión de buenas prácticas (§6) pasa en su mayoría.
- *(Si se hizo la parte opcional)* `podman build` + `podman run` levantan la imagen y `GET /health` responde `{"status":"UP"}`.

---

## 10. Estructura relevante del repo

```
lab3-4-java/                               # carpeta del ZIP / repo
  pom.xml                                  # ahora genera JAR ejecutable (target/app.jar)
  src/main/java/com/claro/lab/
    api/App.java                           # servidor HTTP (JDK), endpoints /health /fare /discount
    discount/InMemoryLoyaltyTierLookup.java# impl en memoria (sin BD/API) para /discount
    pricing/FareCalculator.java            # (Lab 3)
    discount/LoyaltyDiscount.java          # (Lab 3)
    reservation/...                        # (Lab 3)
  # Artefactos que generará Bob en el Lab 4:
  #   Dockerfile
  #   .dockerignore
  #   deployment.yaml / service.yaml / route.yaml (nombres según Bob)
```

---

## 11. Nota sobre Git (importante)

> Si trabajas con el **ZIP** no hay historial de git: para volver al estado limpio, vuelve a descomprimir el ZIP (o crea tu baseline con `git init && git add . && git commit -m LaboratorioBasev1`). Lo siguiente aplica al repo clonado.

La capa HTTP (`api/App.java`, `InMemoryLoyaltyTierLookup.java`), el `pom.xml` con JAR ejecutable y esta guía forman parte del **mismo baseline** que el Lab 3:

| Campo | Valor |
|-------|--------|
| **Mensaje** | `LaboratorioBasev1` |

```bash
# Volver al estado limpio (sin tests de Bob, sin Dockerfile, etc.)
git reset --hard :/LaboratorioBasev1
git clean -fd   # solo si estás seguro
```

> No uses `LaboratorioBasev0` (`e37f884`): no incluye la capa HTTP ni este documento.

Flujo recomendado en el evento: primero Lab 3 (unit testing) → luego Lab 4 (contenerización) sobre el mismo proyecto, idealmente **después** de que existan tests (así el Dockerfile puede correr `mvn verify` si quieres enlazar ambos).

---

## 12. Apéndice — Solución de referencia (para el expositor)

> Sirve para **validar** lo que genera Bob. Idealmente no se comparte con los asistentes hasta el final.

### Dockerfile de referencia (OpenShift-friendly)

```dockerfile
# --- Build stage ---
FROM maven:3.9-eclipse-temurin-17 AS build
WORKDIR /workspace
COPY pom.xml .
RUN mvn -q -e -DskipTests dependency:go-offline
COPY src ./src
RUN mvn -q -DskipTests package
# Para enlazar con el Lab 3, usar en su lugar: RUN mvn -q verify

# --- Runtime stage ---
FROM eclipse-temurin:17-jre AS runtime
WORKDIR /app
COPY --from=build /workspace/target/app.jar /app/app.jar
# Compatibilidad con UID aleatorio de OpenShift (grupo 0 con permisos)
RUN chgrp -R 0 /app && chmod -R g=u /app
EXPOSE 8080
USER 1001
ENV PORT=8080
ENTRYPOINT ["java", "-jar", "/app/app.jar"]
```

> Alternativa 100% Red Hat para OpenShift: base de runtime `registry.access.redhat.com/ubi9/openjdk-17-runtime` (ya viene con usuario no-root 185 y compatible con UID arbitrario).

### `.dockerignore` de referencia

```gitignore
target/
.git/
.gitignore
*.md
.idea/
.vscode/
*.iml
```

### `deployment.yaml` de referencia

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: claro-lab-api
  labels:
    app: claro-lab-api
spec:
  replicas: 1
  selector:
    matchLabels:
      app: claro-lab-api
  template:
    metadata:
      labels:
        app: claro-lab-api
    spec:
      securityContext:
        runAsNonRoot: true
        seccompProfile:
          type: RuntimeDefault
      containers:
        - name: claro-lab-api
          image: claro-lab-api:1.0
          ports:
            - containerPort: 8080
          readinessProbe:
            httpGet:
              path: /health
              port: 8080
            initialDelaySeconds: 3
            periodSeconds: 5
          livenessProbe:
            httpGet:
              path: /health
              port: 8080
            initialDelaySeconds: 10
            periodSeconds: 10
          resources:
            requests:
              cpu: "100m"
              memory: "128Mi"
            limits:
              cpu: "500m"
              memory: "256Mi"
          securityContext:
            allowPrivilegeEscalation: false
            capabilities:
              drop: ["ALL"]
```

### `service.yaml` de referencia

```yaml
apiVersion: v1
kind: Service
metadata:
  name: claro-lab-api
  labels:
    app: claro-lab-api
spec:
  selector:
    app: claro-lab-api
  ports:
    - name: http
      port: 80
      targetPort: 8080
  type: ClusterIP
```

### `route.yaml` de referencia (OpenShift)

```yaml
apiVersion: route.openshift.io/v1
kind: Route
metadata:
  name: claro-lab-api
  labels:
    app: claro-lab-api
spec:
  to:
    kind: Service
    name: claro-lab-api
  port:
    targetPort: 8080
```
