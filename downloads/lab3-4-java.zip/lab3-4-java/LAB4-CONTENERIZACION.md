# Lab 4 — Contenerización con Spec-Driven Development (10 min · opcional)

Laboratorio corto para contenerizar la app del Lab 3 siguiendo **spec-driven development (SDD)**: primero se escribe una **spec** (qué debe cumplir la contenerización y cómo se comprueba), Bob **implementa contra esa spec** y el resultado se **verifica criterio por criterio**.

> A diferencia del Lab 3 (unit testing), aquí el foco **no** son los tests, sino trabajar guiado por una spec y comprobar que los artefactos de contenerización (Dockerfile + manifiestos K8s/OpenShift) la cumplen.

---

## 1. ¿Qué es spec-driven development?

Es una forma de trabajar con agentes donde la **spec** (un documento versionado en el repo) es la fuente de verdad: las personas deciden el *qué* (requisitos y criterios de aceptación) y Bob se encarga del *cómo*. Si el resultado no encaja, se corrige la spec o la implementación; no se improvisa con prompts nuevos.

| | Prompts sueltos | Spec-driven |
|---|---|---|
| **Requisitos** | Viven en el chat y en tu cabeza | Un archivo `spec.md` con IDs (R1…R10) |
| **"Terminado"** | Se ve bien | Criterios de aceptación verificables (CA1…CA5) |
| **Cambios** | Otro prompt, sin rastro | Se edita la spec y se implementa solo la diferencia |
| **Revisión** | Subjetiva | Tabla de trazabilidad requisito → archivo → evidencia |

Bob no necesita un workflow especial: se usan sus modos. **Agent** escribe y ejecuta, **Plan** razona y propone sin tocar código, y **Ask** es de solo lectura (revisor independiente). Referencia de la práctica: [Spec-driven Development with IBM Bob](https://heidloff.net/article/spec-driven-development-ibm-bob/).

---

## 2. Flujo del lab (10 min)

| Paso | Modo de Bob | Tiempo | Resultado |
|---|---|---|---|
| 1 · Escribir la spec | Agent | 3 min | `specs/contenerizacion/spec.md` |
| 2 · Revisar la spec y planear | Plan | 2 min | Ambigüedades detectadas + lista de tareas |
| 3 · Implementar contra la spec | Agent | 3 min | `Dockerfile`, `.dockerignore`, `k8s/*.yaml` |
| 4 · Verificar contra la spec | Ask | 2 min | Tabla de trazabilidad y brechas |

---

## 3. La app a contenerizar

Es el **mismo proyecto** del Lab 3. Tiene una **capa HTTP mínima** (`com.bootcamp.lab.api.App`) con el **servidor embebido del JDK** (`com.sun.net.httpserver`), **sin dependencias nuevas**: puerto 8080 (configurable con `PORT`), `/health` y endpoints de negocio.

| Método HTTP + ruta | Qué hace | Ejemplo |
|--------------------|----------|---------|
| `GET /health` | Estado del servicio (para probes) | `{"status":"UP"}` |
| `GET /fare` | Calcula tarifa (`FareCalculator`) | `/fare?plan=CORPORATE&minutes=150&data=800&peak=true` |
| `GET /discount` | Descuento por lealtad (`LoyaltyDiscount`) | `/discount?customerId=C2&amount=200` |
| `GET /` | Info y lista de endpoints | — |

> Clientes de ejemplo para `/discount`: `C1`=SILVER, `C2`=GOLD, `C3`=PLATINUM, cualquier otro = NONE (`InMemoryLoyaltyTierLookup`, sin BD ni API externa).

### Prerrequisitos

| Requisito | Notas |
|-----------|--------|
| **Bob** | Con el proyecto abierto (carpeta raíz) |
| **JDK 17** + **Maven 3.8+** | Solo para probar la app sin contenedor |
| **Podman** *(preferible)* o **Docker** | Verificación local (opcional) |
| *(Opcional)* `kubectl` u `oc` | Solo si hay cluster |

---

## 4. Paso 1 — Escribir la spec (Agent · 3 min)

En modo **Agent**, pide a Bob que cree el archivo de la spec. Se entrega una spec lista para ahorrar tiempo; **léela y ajústala**: decidir qué se exige le corresponde a la persona, no al agente.

```text
Crea el archivo specs/contenerizacion/spec.md con el siguiente contenido exacto:

# Spec: contenerización de lab-api

## Contexto
App Java 17 (Maven). JAR ejecutable en target/app.jar. Servidor HTTP del JDK en el puerto 8080
(variable PORT). GET /health devuelve {"status":"UP"}.

## Objetivo
Construir una imagen de contenedor y desplegarla en Kubernetes / OpenShift de forma segura y reproducible.

## Fuera de alcance
Registro de imágenes, CI/CD, Helm/Kustomize, bases de datos.

## Requisitos
- R1  Dockerfile multi-stage: la imagen final no contiene Maven ni el JDK completo (solo JRE).
- R2  Imagen base oficial y slim (Temurin 17 JRE o UBI9 openjdk-17-runtime).
- R3  Se ejecuta como no-root y es compatible con el UID arbitrario de OpenShift (grupo 0 con permisos).
- R4  Expone el puerto 8080 y respeta la variable PORT.
- R5  Existe .dockerignore que excluye target/, .git/ y archivos de IDE.
- R6  Deployment de 1 réplica con readinessProbe y livenessProbe a GET /health en el puerto 8080.
- R7  securityContext: runAsNonRoot, allowPrivilegeEscalation: false, capabilities drop ALL, seccompProfile RuntimeDefault.
- R8  Requests y limits de CPU y memoria definidos.
- R9  Service ClusterIP y Route de OpenShift que exponen la app.
- R10 Sin secretos hardcodeados; labels consistentes app=lab-api.

## Criterios de aceptación
- CA1 El Dockerfile y el .dockerignore cumplen R1 a R5 (revisión estática).
- CA2 Los manifiestos en k8s/ cumplen R6 a R10 (revisión estática).
- CA3 "podman build -t lab-api:1.0 ." termina sin errores.
- CA4 Al correr la imagen, GET /health responde {"status":"UP"}.
- CA5 Cada requisito R1 a R10 se puede trazar a un archivo y una línea concreta.
```

> Cada requisito tiene un **ID** (para poder trazarlo) y hay una sección de **fuera de alcance** (para que Bob no invente Helm, CI/CD, etc.).

---

## 5. Paso 2 — Revisar la spec y planear (Plan · 2 min)

Cambia a modo **Plan** (`/plan`). Antes de implementar, pide a Bob que cuestione la spec: una spec ambigua produce una implementación ambigua.

```text
Lee specs/contenerizacion/spec.md.
1. Señala ambigüedades, contradicciones o requisitos que no se puedan verificar.
2. Propón un plan de implementación y una lista de tareas ordenadas; cada tarea debe indicar
   qué requisitos (R#) cubre.
No generes código todavía.
```

Si Bob encuentra problemas reales, corrige la **spec** (no el plan) y vuelve a pedirlo.

---

## 6. Paso 3 — Implementar contra la spec (Agent · 3 min)

Vuelve a modo **Agent**:

```text
Implementa la spec specs/contenerizacion/spec.md siguiendo el plan aprobado.
Genera: Dockerfile, .dockerignore, k8s/deployment.yaml, k8s/service.yaml y k8s/route.yaml.
En un comentario junto a cada decisión indica el requisito que cumple (por ejemplo "# R3").
No modifiques la spec ni el código de la aplicación.
Si algún requisito no es viable, detente y dímelo en lugar de improvisar.
```

> Que Bob **se detenga** ante un requisito inviable es parte del método: el desacuerdo se resuelve en la spec, no con un parche silencioso.

---

## 7. Paso 4 — Verificar contra la spec (Ask · 2 min)

Cambia a modo **Ask** (`/ask`, solo lectura): un revisor independiente que no puede "arreglar" nada a escondidas.

```text
Actúa como revisor. Compara los archivos generados (Dockerfile, .dockerignore, k8s/*.yaml)
con specs/contenerizacion/spec.md.
Para cada requisito R1 a R10 y cada criterio CA1 y CA2, muestra una tabla:
ID | Archivo y línea que lo cumple | Estado (Cumple / Parcial / No cumple) | Evidencia.
Al final lista las brechas y propón si se corrigen en la implementación o en la spec.
```

Si hay brechas, vuelve a **Agent** para corregir solo lo que falta y repite la verificación. Ese ciclo *spec → implementar → verificar* es el corazón del método.

---

## 8. Verificación local (opcional · criterios CA3 y CA4)

### Sin contenedor (sanity check)

```bash
mvn -q -DskipTests package
java -jar target/app.jar
# en otra terminal:
curl http://localhost:8080/health
curl "http://localhost:8080/fare?plan=CORPORATE&minutes=150&data=800&peak=true"
curl "http://localhost:8080/discount?customerId=C2&amount=200"
```

Debe responder `{"status":"UP"}` y los cálculos correspondientes. Detén el proceso con `Ctrl+C`.

### Con Podman (preferible)

```bash
podman build -t lab-api:1.0 .
podman run -d --name lab-api -p 8080:8080 lab-api:1.0
curl http://localhost:8080/health
podman logs lab-api
podman ps
podman stop lab-api && podman rm lab-api
```

### Con Docker (equivalente)

```bash
docker build -t lab-api:1.0 .
docker run -d --name lab-api -p 8080:8080 lab-api:1.0
curl http://localhost:8080/health
docker stop lab-api && docker rm lab-api
```

### Manifiestos como pod local con Podman

```bash
podman kube play k8s/deployment.yaml
podman pod ps
curl http://localhost:8080/health
podman kube down k8s/deployment.yaml
```

### En un cluster (kind / minikube / OpenShift Local)

```bash
kubectl apply -f k8s/deployment.yaml -f k8s/service.yaml
kubectl get pods -w                     # esperar READY 1/1
kubectl port-forward svc/lab-api 8080:80
curl http://localhost:8080/health
# OpenShift: oc apply -f k8s/route.yaml && oc get route
```

---

## 9. Extra — Cambiar la spec (opcional)

Así se evoluciona un proyecto spec-driven: primero cambia el documento y luego se implementa **solo la diferencia**. Por ejemplo, para exigir que los tests del Lab 3 pasen antes de generar la imagen:

```text
Agrega a specs/contenerizacion/spec.md el requisito
"R11  El stage de build ejecuta mvn verify, de modo que la imagen solo se genera si todos los unit tests pasan"
y el criterio "CA6 Un test fallido hace fallar podman build".
Luego implementa únicamente el cambio necesario en el Dockerfile, citando R11, y actualiza la verificación.
```

---

## 10. Criterios de éxito del lab

- La spec existe en el repo, con requisitos con ID y criterios de aceptación.
- Bob generó `Dockerfile`, `.dockerignore` y `k8s/*.yaml` citando los requisitos.
- La tabla de trazabilidad (Paso 4) muestra R1 a R10 como "Cumple", o las brechas están identificadas.
- *(Si se hizo la parte opcional)* `podman build` + `podman run` levantan la imagen y `GET /health` responde `{"status":"UP"}`.

---

## 11. Estructura relevante del repo

```
lab3-4-java/                               # carpeta del ZIP / repo
  pom.xml                                  # genera JAR ejecutable (target/app.jar)
  src/main/java/com/bootcamp/lab/
    api/App.java                           # servidor HTTP (JDK), endpoints /health /fare /discount
    discount/InMemoryLoyaltyTierLookup.java# impl en memoria (sin BD/API) para /discount
    pricing/FareCalculator.java            # (Lab 3)
    discount/LoyaltyDiscount.java          # (Lab 3)
    reservation/...                        # (Lab 3)
  # Lo escribes tú / Bob en el Lab 4:
  #   specs/contenerizacion/spec.md        (Paso 1)
  # Artefactos que generará Bob (Paso 3):
  #   Dockerfile, .dockerignore, k8s/deployment.yaml, k8s/service.yaml, k8s/route.yaml
```

---

## 11b. Nota sobre Git

Si trabajas con el **ZIP** no hay historial de git: para volver al estado limpio, vuelve a descomprimir el ZIP (o crea tu baseline con `git init && git add . && git commit -m LaboratorioBasev1`). Si trabajas con el repo clonado:

```bash
git reset --hard :/LaboratorioBasev1
git clean -fd   # solo si estás seguro
```

Flujo recomendado en el evento: primero Lab 3 (unit testing) → luego Lab 4 (spec-driven + contenerización) sobre el mismo proyecto.

---

## 12. Apéndice — Solución de referencia (para el expositor)

> Sirve para **validar** lo que genera Bob. Idealmente no se comparte con los asistentes hasta el final.

### Dockerfile de referencia (OpenShift-friendly)

```dockerfile
# --- Build stage ---
FROM maven:3.9-eclipse-temurin-17 AS build
WORKDIR /workspace
COPY pom.xml .
RUN mvn -q -e -DskipTests dependency:go-offline
COPY src ./src
RUN mvn -q -DskipTests package
# Para enlazar con el Lab 3, usar en su lugar: RUN mvn -q verify

# --- Runtime stage ---
FROM eclipse-temurin:17-jre AS runtime
WORKDIR /app
COPY --from=build /workspace/target/app.jar /app/app.jar
# Compatibilidad con UID aleatorio de OpenShift (grupo 0 con permisos)
RUN chgrp -R 0 /app && chmod -R g=u /app
EXPOSE 8080
USER 1001
ENV PORT=8080
ENTRYPOINT ["java", "-jar", "/app/app.jar"]
```

> Alternativa 100% Red Hat para OpenShift: base de runtime `registry.access.redhat.com/ubi9/openjdk-17-runtime` (ya viene con usuario no-root 185 y compatible con UID arbitrario).

### `.dockerignore` de referencia

```gitignore
target/
.git/
.gitignore
*.md
.idea/
.vscode/
*.iml
```

### `k8s/deployment.yaml` de referencia

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: lab-api
  labels:
    app: lab-api
spec:
  replicas: 1
  selector:
    matchLabels:
      app: lab-api
  template:
    metadata:
      labels:
        app: lab-api
    spec:
      securityContext:
        runAsNonRoot: true
        seccompProfile:
          type: RuntimeDefault
      containers:
        - name: lab-api
          image: lab-api:1.0
          ports:
            - containerPort: 8080
          readinessProbe:
            httpGet:
              path: /health
              port: 8080
            initialDelaySeconds: 3
            periodSeconds: 5
          livenessProbe:
            httpGet:
              path: /health
              port: 8080
            initialDelaySeconds: 10
            periodSeconds: 10
          resources:
            requests:
              cpu: "100m"
              memory: "128Mi"
            limits:
              cpu: "500m"
              memory: "256Mi"
          securityContext:
            allowPrivilegeEscalation: false
            capabilities:
              drop: ["ALL"]
```

### `k8s/service.yaml` de referencia

```yaml
apiVersion: v1
kind: Service
metadata:
  name: lab-api
  labels:
    app: lab-api
spec:
  selector:
    app: lab-api
  ports:
    - name: http
      port: 80
      targetPort: 8080
  type: ClusterIP
```

### `k8s/route.yaml` de referencia (OpenShift)

```yaml
apiVersion: route.openshift.io/v1
kind: Route
metadata:
  name: lab-api
  labels:
    app: lab-api
spec:
  to:
    kind: Service
    name: lab-api
  port:
    targetPort: 8080
```
