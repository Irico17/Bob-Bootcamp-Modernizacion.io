package com.claro.lab.api;

import com.claro.lab.discount.InMemoryLoyaltyTierLookup;
import com.claro.lab.discount.LoyaltyDiscount;
import com.claro.lab.discount.LoyaltyTier;
import com.claro.lab.pricing.FareCalculator;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;

import java.io.IOException;
import java.io.OutputStream;
import java.math.BigDecimal;
import java.net.InetSocketAddress;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.Executors;

/**
 * Punto de entrada HTTP de la aplicación (Lab 4 — contenerización).
 *
 * <p>Usa el servidor HTTP embebido del JDK ({@code com.sun.net.httpserver})
 * para no añadir dependencias. Expone un endpoint de salud para readiness /
 * liveness probes y dos endpoints que ejercitan la lógica de negocio del Lab 3.
 *
 * <p>Endpoints:
 * <ul>
 *   <li>{@code GET /health} — estado del servicio (para probes de K8s/OpenShift)</li>
 *   <li>{@code GET /fare?plan=PREPAID&minutes=120&data=800&peak=true} — cálculo de tarifa</li>
 *   <li>{@code GET /discount?customerId=C1&amount=100} — descuento por lealtad</li>
 *   <li>{@code GET /} — información y ayuda</li>
 * </ul>
 *
 * <p>El puerto se toma de la variable de entorno {@code PORT} (por defecto 8080)
 * y escucha en {@code 0.0.0.0} para ser accesible dentro del contenedor.
 */
public final class App {

    private static final int DEFAULT_PORT = 8080;

    private static final FareCalculator FARE_CALCULATOR = new FareCalculator();
    private static final LoyaltyDiscount LOYALTY_DISCOUNT =
            new LoyaltyDiscount(new InMemoryLoyaltyTierLookup());

    private App() {
    }

    public static void main(String[] args) throws IOException {
        int port = resolvePort();
        HttpServer server = HttpServer.create(new InetSocketAddress("0.0.0.0", port), 0);

        server.createContext("/health", App::handleHealth);
        server.createContext("/fare", App::handleFare);
        server.createContext("/discount", App::handleDiscount);
        server.createContext("/", App::handleRoot);

        server.setExecutor(Executors.newFixedThreadPool(4));
        server.start();
        System.out.println("Claro Lab API escuchando en http://0.0.0.0:" + port);
    }

    private static int resolvePort() {
        String env = System.getenv("PORT");
        if (env != null && !env.isBlank()) {
            try {
                return Integer.parseInt(env.trim());
            } catch (NumberFormatException ignored) {
                // valor inválido: se usa el puerto por defecto
            }
        }
        return DEFAULT_PORT;
    }

    static void handleHealth(HttpExchange exchange) throws IOException {
        if (!"GET".equalsIgnoreCase(exchange.getRequestMethod())) {
            sendJson(exchange, 405, "{\"error\":\"method not allowed\"}");
            return;
        }
        sendJson(exchange, 200, "{\"status\":\"UP\"}");
    }

    static void handleFare(HttpExchange exchange) throws IOException {
        if (!"GET".equalsIgnoreCase(exchange.getRequestMethod())) {
            sendJson(exchange, 405, "{\"error\":\"method not allowed\"}");
            return;
        }
        Map<String, String> params = queryParams(exchange.getRequestURI());
        try {
            FareCalculator.PlanType plan =
                    FareCalculator.PlanType.valueOf(param(params, "plan", "PREPAID").toUpperCase());
            int minutes = Integer.parseInt(param(params, "minutes", "0"));
            int data = Integer.parseInt(param(params, "data", "0"));
            boolean peak = Boolean.parseBoolean(param(params, "peak", "false"));

            BigDecimal charge = FARE_CALCULATOR.calculate(plan, minutes, data, peak);
            String body = String.format(
                    "{\"plan\":\"%s\",\"minutes\":%d,\"data\":%d,\"peak\":%b,\"charge\":%s}",
                    plan, minutes, data, peak, charge.toPlainString());
            sendJson(exchange, 200, body);
        } catch (IllegalArgumentException ex) {
            sendJson(exchange, 400, "{\"error\":\"" + escape(ex.getMessage()) + "\"}");
        }
    }

    static void handleDiscount(HttpExchange exchange) throws IOException {
        if (!"GET".equalsIgnoreCase(exchange.getRequestMethod())) {
            sendJson(exchange, 405, "{\"error\":\"method not allowed\"}");
            return;
        }
        Map<String, String> params = queryParams(exchange.getRequestURI());
        try {
            String customerId = param(params, "customerId", "");
            BigDecimal amount = new BigDecimal(param(params, "amount", "0"));

            BigDecimal finalAmount = LOYALTY_DISCOUNT.apply(customerId, amount);
            String body = String.format(
                    "{\"customerId\":\"%s\",\"amount\":%s,\"finalAmount\":%s}",
                    escape(customerId), amount.toPlainString(), finalAmount.toPlainString());
            sendJson(exchange, 200, body);
        } catch (IllegalArgumentException | NullPointerException ex) {
            sendJson(exchange, 400, "{\"error\":\"" + escape(ex.getMessage()) + "\"}");
        }
    }

    static void handleRoot(HttpExchange exchange) throws IOException {
        if (!"/".equals(exchange.getRequestURI().getPath())) {
            sendJson(exchange, 404, "{\"error\":\"not found\"}");
            return;
        }
        String body = "{\"service\":\"claro-lab-api\","
                + "\"endpoints\":[\"/health\",\"/fare?plan=PREPAID&minutes=120&data=800&peak=true\","
                + "\"/discount?customerId=C1&amount=100\"]}";
        sendJson(exchange, 200, body);
    }

    private static Map<String, String> queryParams(URI uri) {
        Map<String, String> result = new HashMap<>();
        String query = uri.getRawQuery();
        if (query == null || query.isBlank()) {
            return result;
        }
        for (String pair : query.split("&")) {
            int idx = pair.indexOf('=');
            if (idx > 0) {
                String key = pair.substring(0, idx);
                String value = pair.substring(idx + 1);
                result.put(key, java.net.URLDecoder.decode(value, StandardCharsets.UTF_8));
            }
        }
        return result;
    }

    private static String param(Map<String, String> params, String key, String defaultValue) {
        String value = params.get(key);
        return (value == null || value.isBlank()) ? defaultValue : value;
    }

    private static String escape(String value) {
        if (value == null) {
            return "";
        }
        return value.replace("\\", "\\\\").replace("\"", "\\\"");
    }

    private static void sendJson(HttpExchange exchange, int status, String body) throws IOException {
        byte[] bytes = body.getBytes(StandardCharsets.UTF_8);
        exchange.getResponseHeaders().set("Content-Type", "application/json; charset=utf-8");
        exchange.sendResponseHeaders(status, bytes.length);
        try (OutputStream os = exchange.getResponseBody()) {
            os.write(bytes);
        }
    }
}
