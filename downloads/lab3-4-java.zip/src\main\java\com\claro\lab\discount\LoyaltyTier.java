package com.claro.lab.discount;

/**
 * Nivel de lealtad del cliente en el programa Claro.
 */
public enum LoyaltyTier {
    NONE,
    SILVER,
    GOLD,
    PLATINUM
}
